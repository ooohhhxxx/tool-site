# -*- coding: utf-8 -*-
"""方案 A 的最小可运行入口：pywebview 窗口 + JS 桥接。

运行：
    python webui/app.py

它会开一个 WebView2 窗口加载 frontend/index.html，并把 BridgeAPI 注入为
window.pywebview.api。现有 ssh_modbus_tool.py 完全不参与，可随时回退：
    git reset --hard v1.6.7-baseline && git clean -fd
"""
from __future__ import annotations

import pathlib
import sys

# 说明：这里曾尝试在 import webview 之前用 pythonnet.load(get_coreclr(...))
# 绕开打包后 .NET Framework 的加载问题，结论是走不通 —— coreclr 起来了但
# System.Windows.Forms 没被导入（runtimeconfig 声明的 WindowsDesktop 框架不生效），
# pywebview 的 winforms 后端仍然起不来。已回退为 pywebview 默认后端；
# 打包方案见 README「打包状态」一节。
import webview

HERE = pathlib.Path(__file__).resolve().parent
FROZEN = bool(getattr(sys, 'frozen', False))
if FROZEN:
    # PyInstaller 下前端在 _MEIPASS/frontend，app.ico 在 _MEIPASS 根
    _BASE = pathlib.Path(getattr(sys, '_MEIPASS', pathlib.Path(sys.executable).parent))
    HERE = _BASE
    ROOT = _BASE
else:
    ROOT = HERE.parent

FRONTEND = HERE / 'frontend' / 'index.html'

if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

# pythonw.exe 下 stdout/stderr 是 None：任何一句 print 都会抛 AttributeError，
# 而异常又被 GUI 吞掉，表现就是"窗口卡住、什么都没发生"。
# 统一重定向到 logs/app.log，既避免崩溃，也让出问题时能查。
def _setup_headless_logging():
    if sys.stdout is not None and sys.stderr is not None:
        return
    try:
        log_dir = ROOT / 'logs'
        log_dir.mkdir(parents=True, exist_ok=True)
        f = open(log_dir / 'app.log', 'a', encoding='utf-8', buffering=1)
        sys.stdout = f
        sys.stderr = f
        sys.stdin = open('nul', 'r')
    except Exception:
        pass


_setup_headless_logging()

from bridge import BridgeAPI  # noqa: E402
from host import SingleInstance, enable_dpi_awareness, show_message  # noqa: E402
from trayhost import TrayHost  # noqa: E402

ICON = ROOT / 'app.ico'

# pystray 必须在主线程 import：
# 首次 import 会初始化 Win32 后端（注册窗口类），在子线程里做会和 WebView2 的
# COM 初始化撞上，实测直接卡死在 import 这一行（available() 都回不来）。
try:
    import pystray as _pystray_preload  # noqa: F401
except Exception:
    _pystray_preload = None


def read_close_action():
    """读真实配置 ui.close_action（与 Tk 版共用同一个配置文件）。"""
    try:
        from core import ConfigStore
        store = ConfigStore()
        if store.load()['ok']:
            return str(store.get('ui', 'close_action', 'exit') or 'exit')
    except Exception:
        pass
    return 'exit'


def create_window(api=None):
    api = api or BridgeAPI()
    win = webview.create_window(
        '调试工具 · Web UI 桥接骨架',
        str(FRONTEND),
        js_api=api,
        width=1280,
        height=800,
        min_size=(1024, 680),
        background_color='#F4F7FB',
        text_select=True,
    )
    # 桥接层要能弹文件对话框（上传选文件、下载选保存位置）
    api.window = win
    return win


def main():
    # DPI 必须在创建任何窗口之前声明；单实例要在建窗口之前判定
    enable_dpi_awareness()
    guard = SingleInstance()
    if not guard.acquire():
        show_message('调试工具', guard.message + '\n\n请先关闭已经在运行的窗口。')
        return 1
    if not FRONTEND.is_file():
        raise SystemExit('找不到前端文件: ' + str(FRONTEND))
    win = create_window()

    state = {'force_quit': False}

    def quit_app():
        state['force_quit'] = True
        try:
            win.destroy()
        except Exception:
            pass

    tray = TrayHost(win, ICON, on_quit=quit_app)

    def on_closing():
        # 返回 False = 取消关闭（pywebview 的 closing 事件语义）
        if state['force_quit']:
            return True
        if read_close_action() == 'tray' and tray.hide_to_tray():
            return False
        tray.stop()
        return True

    win.events.closing += on_closing
    # private_mode=False + storage_path：否则 pywebview 每次启动都在**当前工作目录**
    # 建一个 tmpXXXXXXXX\EBWebView（7~44MB），退出还不清理，程序目录很快就堆满垃圾。
    # Windows 上 pywebview 6 自动选 EdgeChromium (WebView2)；显式写出来便于排查
    webview.start(gui='edgechromium', debug=False, private_mode=False,
                  storage_path=str(ROOT / 'data'))
    return 0


if __name__ == '__main__':
    sys.exit(main())
