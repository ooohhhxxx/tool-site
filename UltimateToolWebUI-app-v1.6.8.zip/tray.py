# -*- coding: utf-8 -*-
"""系统托盘图标：关闭窗口后驻留后台。

独立成模块的原因：
1. 主文件已经 8000 行，不该再塞一层第三方库的适配代码；
2. pystray 只在「最小化到托盘」启用时才需要，导入失败不该影响主程序启动；
3. 托盘菜单的回调在 pystray 自己的线程里，所有 Tk 操作必须经 root.after
   回主线程——把这个约束收在一个地方，比散落在主文件里安全。
"""
from __future__ import annotations

import os
import threading


class TrayController:
    """一个托盘图标的生命周期封装（show / hide）。

    用法：
        tray = TrayController(app, 'app.ico')
        if tray.show():          # 失败返回 False，调用方负责降级
            ...
    """

    def __init__(self, app, icon_path):
        self.app = app
        self.icon_path = icon_path
        self._icon = None
        self._thread = None
        self._lock = threading.Lock()

    # ---------- 可用性探测 ----------
    @staticmethod
    def available():
        """当前环境能否使用托盘（缺库或系统不支持时返回 False）。"""
        try:
            import pystray
            from PIL import Image
            # 真正引用一下：只 import 不引用会被静态检查判成未使用；
            # 顺便确认后端确实提供了 Icon 与图片解码能力
            return hasattr(pystray, 'Icon') and hasattr(Image, 'open')
        except Exception:
            return False

    # ---------- 显示 / 隐藏 ----------
    def show(self):
        """显示托盘图标。成功返回 True；失败返回 False（不抛异常）。"""
        with self._lock:
            # 必须同时确认线程还活着：pystray 后端在 run() 里崩溃时线程会退出，
            # 但 _icon 仍非空。若此时直接返回 True，调用方会放心地隐藏窗口，
            # 结果窗口和图标都没有 —— 用户只能任务管理器杀进程。
            if (self._icon is not None and self._thread is not None
                    and self._thread.is_alive()):
                return True
            if self._icon is not None:
                # 残留的死图标：先清掉再重建，别让它挡住下一次尝试
                stale, self._icon = self._icon, None
                self._thread = None
                try:
                    stale.stop()
                except Exception:
                    pass
            try:
                import pystray
                from PIL import Image

                if not os.path.exists(self.icon_path):
                    return False
                image = Image.open(self.icon_path)
                menu = pystray.Menu(
                    # default=True：双击图标直接执行这一项（恢复窗口）
                    pystray.MenuItem("显示主窗口", self._on_show, default=True),
                    pystray.MenuItem("退出", self._on_quit),
                )
                icon = pystray.Icon("ultimate_tool", image,
                                    "SSH & Modbus & 串口 调试工具", menu)
                # run() 会阻塞并自建消息循环，必须放在独立线程
                thread = threading.Thread(target=icon.run, daemon=True,
                                          name="tray-icon")
                thread.start()
                self._icon = icon
                self._thread = thread
                return True
            except Exception:
                self._icon = None
                self._thread = None
                return False

    def hide(self):
        """移除托盘图标（窗口恢复或程序退出时调用）。"""
        with self._lock:
            icon, self._icon = self._icon, None
            self._thread = None
        if icon is not None:
            try:
                icon.stop()
            except Exception:
                pass

    @property
    def visible(self):
        return self._icon is not None

    @property
    def alive(self):
        """图标对象在、且 run() 线程还活着。

        `visible` 只看 _icon 是否非空，但 pystray 的 run() 有可能刚启动就崩
        （系统通知区异常），那时线程已死、_icon 还在。调用方需要靠这个判断
        「窗口藏起来之后还能不能找回来」。
        """
        with self._lock:
            return (self._icon is not None and self._thread is not None
                    and self._thread.is_alive())

    def notify(self, message, title=None):
        """弹一个托盘气泡（不打断、不会把主窗口拉回来）。"""
        if self._icon is None:
            return False
        try:
            self._icon.notify(message, title)
            return True
        except Exception:
            return False

    # ---------- 回调（pystray 线程 → 主线程） ----------
    def _ui_call(self, fn, *args):
        """把动作排回 Tk 主线程。pystray 回调里绝不能直接碰控件。

        必须走主程序的 `_ui_call`（入队 + 主线程泵），**不能用 `root.after(0, ...)`**：
        菜单回调在 pystray 自己的线程里，跨线程调 after 会走 Tcl 的
        `Misc.after → _register → tk.createcommand`，主线程不在 mainloop
        （正在 update() / 模态框里）时会抛 "main thread is not in main loop"，
        甚至把菜单线程一起卡住。这个坑主程序里已经统一收口过，这里复用即可。
        """
        try:
            self.app._ui_call(fn, *args)
        except Exception:
            pass

    def _on_show(self, icon=None, item=None):
        self._ui_call(self.app.show_from_tray)

    def _on_quit(self, icon=None, item=None):
        # 退出必须走统一的收尾入口，否则日志文件、连接、插件线程收不干净
        self._ui_call(self.app._shutdown)
