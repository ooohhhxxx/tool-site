' Ultimate Tool - Web UI edition launcher (no console window)
Option Explicit
Dim fso, sh, base
Set fso = CreateObject("Scripting.FileSystemObject")
Set sh = CreateObject("WScript.Shell")
base = fso.GetParentFolderName(WScript.ScriptFullName)
sh.CurrentDirectory = base
sh.Run """" & base & "\python\pythonw.exe"" """ & base & "\app\app.py""", 0, False
