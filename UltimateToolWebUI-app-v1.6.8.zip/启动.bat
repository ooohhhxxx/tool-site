@echo off
REM Fallback launcher (the .lnk shortcut is preferred; this one flashes a console window)
cd /d "%~dp0"
start "" "%~dp0python\pythonw.exe" "%~dp0app\app.py"
