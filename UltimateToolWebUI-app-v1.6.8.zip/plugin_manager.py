# -*- coding: utf-8 -*-
"""插件管理器：发现 / 加载 / 卸载 / 重载 / 启停 / 在后台线程里执行插件命令。

本模块刻意不依赖 tkinter —— 宿主把 GUI 实例（app）注入进来，
通过 app 的 `api_*` 方法访问 SSH / Modbus / 串口能力，
因此可以脱离界面单独做单元测试（见 verify_plugins.py）。
"""

from __future__ import annotations

import ast
import importlib.util
import json
import os
import re
import sys
import threading
import time
import traceback
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

import plugin_api  # noqa: E402
from plugin_api import Command, ExecResult, PluginBase, PluginError  # noqa: E402

#: 包一层，保证插件里 `import plugin_api` 一定拿得到同一个模块对象
sys.modules.setdefault('plugin_api', plugin_api)

STATE_FILENAME = '.ssh_gui_plugins.json'
LOG_LEVELS = ('info', 'success', 'warn', 'error')

#: 帮助用户理解：插件里可以直接 import 同目录下的其它 .py 文件
PLUGIN_MODULE_PREFIX = 'sshgui_plugin_'


def default_plugin_dirs(extra: Optional[Sequence[str]] = None) -> List[str]:
    """返回候选插件目录，**越靠后优先级越高**（同名插件后者覆盖前者）。"""
    dirs: List[str] = []

    def add(path: Optional[str]) -> None:
        if path and path not in dirs:
            dirs.append(path)

    # PyInstaller onefile：示例插件被打包进解包目录
    meipass = getattr(sys, '_MEIPASS', None)
    if meipass:
        add(os.path.join(meipass, 'plugins'))
    # 打包成 exe 后，exe 同级目录是用户放插件的地方
    if getattr(sys, 'frozen', False):
        add(os.path.join(os.path.dirname(sys.executable), 'plugins'))
    # 源码目录
    add(os.path.join(_HERE, 'plugins'))
    add(os.path.join(os.getcwd(), 'plugins'))
    if extra:
        for d in extra:
            add(os.path.abspath(d))
    # 用户级插件目录（优先级最高，可覆盖内置插件）
    add(os.path.join(os.path.expanduser('~'), '.ssh_gui_plugins'))
    return dirs


def safe_name(name: str) -> str:
    """把插件名转成可做文件名/模块名的形式。"""
    return re.sub(r'[^0-9A-Za-z_\u4e00-\u9fff-]+', '_', str(name)).strip('_') or 'plugin'


def drop_bytecode(path: str) -> None:
    """删掉 __pycache__ 里的 .pyc。

    Python 判断缓存是否新鲜只看「源文件 mtime + 大小」且 mtime 精确到秒：
    用户改插件时若文件大小没变、修改又发生在同一秒内，重载会拿到旧代码。
    显式删缓存可以彻底避免这种「改了没生效」的诡异现象。
    """
    try:
        cache = importlib.util.cache_from_source(path)
    except (NotImplementedError, ValueError):
        return
    try:
        os.remove(cache)
    except OSError:
        pass


#: 插件覆盖这个属性（`ENABLED_BY_DEFAULT = False`）即可默认不启用
_DEFAULT_FLAG = 'ENABLED_BY_DEFAULT'
#: 超过这个大小就不做静态扫描。解析发生在启动和「重载」的主线程路径上，
#: 一个几 MB 的畸形插件文件能把界面卡住十几秒（实测 12MB → 13 秒）。
#: 真正的插件都是几十 KB，1MB 已经宽到没有意义。
_MAX_SCAN_BYTES = 1024 * 1024


def _decl_scope_statements(tree: ast.Module):
    """模块体的直接语句 + 模块级类体的直接语句，按源码顺序。

    文档里的写法是类属性（`class Xx(PluginBase): ENABLED_BY_DEFAULT = False`），
    所以类体要算；函数体里的同名赋值只是局部变量，算进来会让一个局部变量把整个
    插件静默禁用掉。if / try / with 里面的也不算：`if sys.platform == 'linux':`
    这种条件声明静态读不出真假，而猜错的方向是「无声少加载一个插件」，比多加载
    一个难查得多，所以一律当成认不出。
    """
    for node in tree.body:
        yield node
        if isinstance(node, ast.ClassDef):
            for sub in node.body:
                yield sub


def read_default_enabled(path: str) -> bool:
    """静态读插件源码里的 ENABLED_BY_DEFAULT，不导入模块。

    这一步必须发生在导入之前：为了知道该不该加载而先 import 一遍，等于把
    插件的 on_load、面板构建全跑完再把它藏起来，那就不是「默认不启用」。
    认不出的写法（条件语句里、海象赋值、从别处 import 进来的名字、超大文件、
    编码不对）一律按启用处理：多加载一个插件在列表里看得见，少加载一个无声无息。
    """
    try:
        if os.path.getsize(path) > _MAX_SCAN_BYTES:
            return True
        # utf-8-sig：记事本存的文件带 BOM，按 utf-8 读会让 ast.parse 直接语法错误，
        # 声明就这么静默失效了（插件照样自动加载，用户看不出区别）
        with open(path, 'r', encoding='utf-8-sig') as fh:
            tree = ast.parse(fh.read(), filename=path)
    except (OSError, UnicodeDecodeError, SyntaxError, ValueError,
            RecursionError, MemoryError):
        return True
    result = True
    for node in _decl_scope_statements(tree):
        if isinstance(node, ast.Assign):
            targets, value = node.targets, node.value
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            targets, value = [node.target], node.value
        else:
            continue
        if not isinstance(value, ast.Constant):
            continue
        for t in targets:
            if not isinstance(t, ast.Name) or t.id != _DEFAULT_FLAG:
                continue
            # 后写的覆盖先写的，与 Python 自己的语义一致
            if value.value is False:
                result = False
            elif value.value is True:
                result = True
    return result


class PluginRecord:
    """一个插件文件在管理器中的状态。"""

    def __init__(self, path: str, directory: str):
        self.path = os.path.abspath(path)
        self.directory = directory
        self.stem = os.path.splitext(os.path.basename(path))[0]
        self.module = None
        self.instance: Optional[Any] = None
        self.context: Optional['PluginContext'] = None
        self.error = ''
        self.loaded = False
        self.default_enabled = read_default_enabled(self.path)

    # ---- 展示信息（未加载时回退到文件名） ----
    @property
    def name(self) -> str:
        return self.stem

    @property
    def display_name(self) -> str:
        return str(getattr(self.instance, 'NAME', self.stem))

    @property
    def version(self) -> str:
        return str(getattr(self.instance, 'VERSION', '-'))

    @property
    def description(self) -> str:
        return str(getattr(self.instance, 'DESCRIPTION', ''))

    @property
    def author(self) -> str:
        return str(getattr(self.instance, 'AUTHOR', ''))

    @property
    def requires(self) -> Sequence[str]:
        return tuple(getattr(self.instance, 'REQUIRES', ()) or ())

    def __repr__(self) -> str:  # pragma: no cover - 调试用
        return '<PluginRecord %s loaded=%s>' % (self.stem, self.loaded)


class _ApiBase:
    def __init__(self, ctx: 'PluginContext'):
        self._ctx = ctx

    @property
    def _app(self):
        return self._ctx.app

    def _call(self, method: str, *args, **kwargs):
        fn = getattr(self._app, method, None)
        if fn is None:
            raise PluginError('宿主未实现 %s()，可能是插件与工具版本不匹配' % method)
        return fn(*args, **kwargs)


class SshApi(_ApiBase):
    @property
    def connected(self) -> bool:
        try:
            return bool(self._call('api_ssh_connected'))
        except Exception:
            return False

    def ensure(self) -> None:
        self._ctx.ensure('ssh')

    @property
    def cwd(self) -> str:
        return str(self._call('api_ssh_cwd'))

    def exec(self, cmd: str, timeout: int = 15) -> ExecResult:
        self.ensure()
        res = self._call('api_ssh_exec', str(cmd), timeout)
        if isinstance(res, ExecResult):
            return res
        status, out, err = (list(res) + ['', ''])[:3]
        return ExecResult(int(status), str(out), str(err))

    def listdir(self, path: Optional[str] = None) -> List[Dict[str, Any]]:
        self.ensure()
        return [dict(x) for x in self._call('api_sftp_listdir', path)]

    def stat(self, path: str) -> Dict[str, Any]:
        self.ensure()
        return dict(self._call('api_sftp_stat', path))

    def upload(self, local: str, remote: str, callback: Optional[Callable] = None) -> None:
        self.ensure()
        self._call('api_sftp_upload', local, remote, callback)

    def download(self, remote: str, local: str, callback: Optional[Callable] = None) -> None:
        self.ensure()
        self._call('api_sftp_download', remote, local, callback)

    def read_text(self, path: str, encoding: str = 'utf-8') -> str:
        self.ensure()
        return str(self._call('api_sftp_read_text', path, encoding))

    def write_text(self, path: str, text: str, encoding: str = 'utf-8') -> None:
        self.ensure()
        self._call('api_sftp_write_text', path, str(text), encoding)


class ModbusApi(_ApiBase):
    READ_KINDS = ('coil', 'discrete', 'holding', 'input')
    WRITE_KINDS = ('coil', 'coils', 'holding', 'holdings')

    @property
    def connected(self) -> bool:
        try:
            return bool(self._call('api_modbus_connected'))
        except Exception:
            return False

    def ensure(self) -> None:
        self._ctx.ensure('modbus')

    def read(self, kind: str, addr: int, count: int = 1) -> List[Any]:
        self.ensure()
        kind = str(kind).lower()
        if kind not in self.READ_KINDS:
            raise PluginError('不支持的读取类型 %r，可选: %s' % (kind, '/'.join(self.READ_KINDS)))
        return list(self._call('api_modbus_read', kind, int(addr), int(count)))

    def write(self, kind: str, addr: int, value) -> bool:
        self.ensure()
        kind = str(kind).lower()
        if kind not in self.WRITE_KINDS:
            raise PluginError('不支持的写入类型 %r，可选: %s' % (kind, '/'.join(self.WRITE_KINDS)))
        return bool(self._call('api_modbus_write', kind, int(addr), value))


class SerialApi(_ApiBase):
    @property
    def connected(self) -> bool:
        try:
            return bool(self._call('api_serial_connected'))
        except Exception:
            return False

    def ensure(self) -> None:
        self._ctx.ensure('serial')

    def ports(self) -> List[str]:
        return [str(p) for p in self._call('api_serial_ports')]

    def send(self, data) -> None:
        self.ensure()
        if isinstance(data, str):
            # 文本交给宿主编：串口界面上选的编码同时管着收发两个方向，
            # 插件不该自己另定一套（原来这里固定 UTF-8，选 GBK 的设备收不到中文）
            self._call('api_serial_send_str', data)
            return None
        self._call('api_serial_send', bytes(data))
        return None

    def send_line(self, text: str, ending: str = '\n') -> None:
        self.send(str(text) + ending)

    def read(self, timeout: float = 0.5) -> bytes:
        self.ensure()
        return bytes(self._call('api_serial_read', float(timeout)))

    def flush(self) -> None:
        self._call('api_serial_flush')
        return None


class PluginContext:
    """注入给单个插件的宿主对象（就是插件里那个 host）。"""

    def __init__(self, manager: 'PluginManager', record: PluginRecord):
        self.manager = manager
        self.app = manager.app
        self.plugin = record.instance
        self.plugin_name = record.stem
        self.plugin_dir = record.directory
        self.api_version = plugin_api.PLUGIN_API_VERSION
        self.stop_event = threading.Event()
        self.ssh = SshApi(self)
        self.modbus = ModbusApi(self)
        self.serial = SerialApi(self)

    # ---------------- 日志 ----------------
    def log(self, msg, level: str = 'info') -> None:
        self.manager._emit(self.plugin_name, str(msg), level)

    def info(self, msg) -> None:
        self.log(msg, 'info')

    def success(self, msg) -> None:
        self.log(msg, 'success')

    def warn(self, msg) -> None:
        self.log(msg, 'warn')

    def error(self, msg) -> None:
        self.log(msg, 'error')

    # ---------------- 流程控制 ----------------
    def sleep(self, seconds: float) -> bool:
        """可被「停止」打断的等待；返回 False 表示插件已被要求停止。"""
        end = time.monotonic() + max(0.0, float(seconds))
        while True:
            if self.stop_event.is_set():
                return False
            remain = end - time.monotonic()
            if remain <= 0:
                return True
            self.stop_event.wait(min(0.1, remain))

    @property
    def stop_requested(self) -> bool:
        return self.stop_event.is_set()

    def ensure(self, kind: str) -> bool:
        api = {'ssh': self.ssh, 'modbus': self.modbus, 'serial': self.serial}.get(str(kind).lower())
        if api is None:
            raise PluginError('未知依赖 %r（可选 ssh / modbus / serial）' % (kind,))
        if not api.connected:
            label = {'ssh': 'SSH', 'modbus': 'Modbus TCP', 'serial': '串口'}[str(kind).lower()]
            raise PluginError('%s 尚未连接，请先到对应标签页连接' % label)
        return True

    @property
    def is_busy(self) -> bool:
        """这个插件当前有没有任务在跑（面板按钮用它做防连点）。"""
        return self.manager.is_running(self.plugin_name)

    def _finish(self) -> None:
        self.manager._release(self.plugin_name, threading.current_thread())

    def run_async(self, func: Callable, *args, **kwargs):
        """在后台线程执行 func；异常会写进插件日志而不是静默丢失。

        同一插件已有任务在跑时不会起第二个线程，改为在日志里提示，并返回 None
        ——面板回调应据此回滚自己的「进行中」状态，否则复选框会显示在跑而实际没跑。
        """
        # 先建线程再占位：占位表里存的就是这个线程对象，is_running 才能判断它
        # 是否还活着（详见 PluginManager._claim）。
        def runner():
            try:
                func(*args, **kwargs)
            except PluginError as exc:
                self.manager._emit(self.plugin_name, str(exc), 'error')
            except Exception as exc:  # noqa: BLE001 - 后台线程必须兜住所有异常
                self.manager._emit(
                    self.plugin_name,
                    '后台任务异常: %s: %s' % (type(exc).__name__, exc),
                    'error',
                )
                self.manager._emit(self.plugin_name, traceback.format_exc().strip(), 'error')
            finally:
                self._finish()

        t = threading.Thread(target=runner, daemon=True,
                             name='plugin-%s-task' % self.plugin_name)
        if not self.manager._claim(self.plugin_name, t, self):
            self.manager._emit(self.plugin_name,
                               '上一个任务还在执行，本次请求已忽略（可点「停止」中断）',
                               'warn')
            return None
        # 清停止标志这步以前只有 run_command 做，run_async 从来没做过。
        # 后果是：用户按一次面板上的「停止」，stop_event 就一直是置位的，之后
        # 凡是检查 host.stop_requested 的面板功能（循环发送 / 扫描 / 批量执行）
        # 一进去就自退，表现为「这个勾选框之后怎么点都没反应」，而且完全无声；
        # 只有恰好从命令表跑一次命令才会被顺带 clear。
        self.stop_event.clear()
        if not self.manager._start_claimed(self.plugin_name, t):
            return None
        return t

    @property
    def data_dir(self) -> str:
        path = os.path.join(os.path.expanduser('~'), '.ssh_gui_plugin_data', safe_name(self.plugin_name))
        try:
            os.makedirs(path, exist_ok=True)
        except OSError:
            pass
        return path


class PluginManager:
    """插件的发现、生命周期与执行。"""

    def __init__(
        self,
        app,
        log: Optional[Callable[[str, str, str], None]] = None,
        plugin_dirs: Optional[Sequence[str]] = None,
        state_file: Optional[str] = None,
        auto_load: bool = True,
    ):
        self.app = app
        #: log(plugin_name, message, level)
        self._log = log
        self.plugin_dirs = default_plugin_dirs(plugin_dirs)
        self.state_file = state_file or os.path.join(os.path.expanduser('~'), STATE_FILENAME)
        self.records: Dict[str, PluginRecord] = {}
        #: 被同名高优先级文件盖住的低优先级副本：stem -> 那些不会生效的路径
        self.shadowed: Dict[str, List[str]] = {}
        #: 最近一次 discover() 真正扫到的目录（目录不存在的不算）
        self.scanned_dirs: List[str] = []
        self._load_state()
        #: 执行位账本：name -> (线程, 派发时那个 context)。
        #: 存 context 是为了「停止」按钮：卸载后 rec.context 是 None、重载后是新的
        #: 一个，只有账本里这份才连着仍在跑的旧任务。
        self._running: Dict[str, Tuple[threading.Thread, 'PluginContext']] = {}
        self._lock = threading.RLock()
        self._closed = False
        if auto_load:
            self.discover()
            self.load_all()
            self._emit('manager', '插件目录: %s' % (' 、'.join(self.scanned_dirs) or '（无）'), 'info')

    # ---------------- 日志 ----------------
    def _emit(self, plugin_name: str, msg: str, level: str = 'info') -> None:
        level = level if level in LOG_LEVELS else 'info'
        ts = time.strftime('%H:%M:%S')
        line = '[%s] [%s] %s' % (ts, plugin_name, msg)
        if self._log:
            try:
                self._log(plugin_name, msg, level)
                return
            except Exception:
                pass
        print(line, flush=True)

    # ---------------- 发现 ----------------
    def discover(self) -> List[PluginRecord]:
        """扫描插件目录，刷新 records（已加载的插件不会被重复加载）。"""
        with self._lock:
            found: Dict[str, str] = {}
            shadowed: Dict[str, List[str]] = {}
            scanned: List[str] = []
            for d in self.plugin_dirs:
                if not d or not os.path.isdir(d):
                    continue
                scanned.append(d)
                try:
                    entries = sorted(os.listdir(d))
                except OSError:
                    continue
                for fn in entries:
                    if not fn.endswith('.py') or fn.startswith('_'):
                        continue
                    stem = os.path.splitext(fn)[0]
                    path = os.path.join(d, fn)
                    if stem in found and found[stem] != path:
                        # 三份同名时前两份都不会生效，所以要累加而不是覆盖
                        shadowed.setdefault(stem, []).append(found[stem])
                    found[stem] = path  # 后面的目录优先级更高
            self.scanned_dirs = scanned
            # 每次扫描重建：以前只增不减，插件被删掉后阴影提示会一直挂在账上
            old_shadowed = self.shadowed
            self.shadowed = shadowed
            # 移除已经消失的插件（先卸载再删记录）
            for stem in list(self.records):
                if stem not in found:
                    self.unload(stem)
                    del self.records[stem]
            # 新增插件
            for stem, path in found.items():
                rec = self.records.get(stem)
                if rec is None:
                    self.records[stem] = PluginRecord(path, os.path.dirname(path))
                elif os.path.abspath(rec.path) != os.path.abspath(path):
                    self.unload(stem)
                    self.records[stem] = PluginRecord(path, os.path.dirname(path))
                else:
                    # 路径没变但源码可能改了。不重算的话，改完 ENABLED_BY_DEFAULT
                    # 再点「重载」仍按旧值判定，看起来像这个声明根本不生效。
                    rec.default_enabled = read_default_enabled(path)
            for stem, losers in shadowed.items():
                if old_shadowed.get(stem) != losers:
                    self._emit(stem, '同名插件被覆盖，实际加载的是 %s；这 %d 份不会生效: %s'
                               % (self.records[stem].path if stem in self.records else '?',
                                  len(losers), ' 、'.join(losers)),
                               'warn')
            return list(self.records.values())

    def names(self) -> List[str]:
        return sorted(self.records)

    # ---------------- 启用状态 ----------------
    def _load_state(self) -> None:
        """读回用户手动开关过的插件名。

        旧版状态文件只有 disabled，缺 enabled 是正常的：没被手动动过的插件
        走源码里声明的 ENABLED_BY_DEFAULT。
        """
        self._disabled = set()
        self._enabled = set()
        try:
            # utf-8-sig：状态文件被记事本改过一次就会带 BOM，按 utf-8 读会当成
            # 「文件损坏」——插件开关设置全部按默认值启动（读插件源码那处同理）。
            with open(self.state_file, 'r', encoding='utf-8-sig') as f:
                data = json.load(f)
        except FileNotFoundError:
            return                      # 首次运行，还没存过状态
        except Exception as exc:  # noqa: BLE001 - 状态读不出来不该挡住启动
            # 但必须说一声：静默 return 的话，用户禁用的插件会全部自动加载，
            # 而他完全不知道自己的设置丢了，下一次保存还会把坏文件覆盖掉。
            self._emit('manager', '插件开关状态读不出来（%s: %s），本次按默认值启动'
                       % (type(exc).__name__, exc), 'warn')
            return
        if not isinstance(data, dict):
            self._emit('manager', '插件开关状态格式不对（不是 JSON 对象），本次按默认值启动', 'warn')
            return
        for key, target in (('disabled', self._disabled), ('enabled', self._enabled)):
            for name in (data.get(key) or []):
                target.add(str(name))

    def _save_state(self) -> None:
        #: 先写临时文件再替换：直接覆写时如果中途崩溃/断电，开关状态就变成半个
        #: JSON，下次启动 _load_state 会静默吞掉它，用户禁用的插件又全都自动加载了。
        tmp = self.state_file + '.tmp'
        try:
            with open(tmp, 'w', encoding='utf-8') as f:
                json.dump({'disabled': sorted(self._disabled),
                           'enabled': sorted(self._enabled)}, f, ensure_ascii=False, indent=2)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp, self.state_file)
        except Exception as exc:  # noqa: BLE001 - 存不下来不该影响使用
            self._emit('manager', '保存插件开关状态失败: %s' % exc, 'warn')
            try:
                os.remove(tmp)
            except OSError:
                pass

    def is_enabled(self, name: str) -> bool:
        if name in self._disabled:
            return False
        if name in self._enabled:
            return True
        rec = self.records.get(name)
        return True if rec is None else rec.default_enabled

    def set_enabled(self, name: str, enabled: bool) -> bool:
        if name not in self.records:
            return False
        if enabled:
            self._disabled.discard(name)
            self._enabled.add(name)
            self._save_state()
            return self.load(name)
        self._disabled.add(name)
        self._enabled.discard(name)
        self._save_state()
        self.unload(name)
        self._emit(name, '已禁用', 'info')
        return True

    # ---------------- 生命周期 ----------------
    def load(self, name: str) -> bool:
        with self._lock:
            rec = self.records.get(name)
            if rec is None:
                self._emit(name, '插件不存在', 'error')
                return False
            if rec.loaded:
                return True
            rec.error = ''
            mod_name = PLUGIN_MODULE_PREFIX + safe_name(name)
            try:
                drop_bytecode(rec.path)      # 保证「重载」一定读到刚改过的源码
                spec = importlib.util.spec_from_file_location(mod_name, rec.path)
                if spec is None or spec.loader is None:
                    raise PluginError('无法为 %s 创建加载器' % rec.path)
                module = importlib.util.module_from_spec(spec)
                sys.modules[mod_name] = module
                added = rec.directory not in sys.path
                if added:
                    sys.path.insert(0, rec.directory)  # 允许插件 import 同目录的辅助模块
                try:
                    spec.loader.exec_module(module)
                finally:
                    if added:
                        try:
                            sys.path.remove(rec.directory)
                        except ValueError:
                            pass
                obj = getattr(module, 'PLUGIN', None)
                if obj is None:
                    obj = getattr(module, 'Plugin', None)
                if obj is None:
                    raise PluginError('未找到 PLUGIN / Plugin，请在插件文件末尾写 PLUGIN = Plugin')
                instance = obj() if isinstance(obj, type) else obj
                if not hasattr(instance, 'NAME') and not isinstance(instance, PluginBase):
                    raise PluginError('PLUGIN 必须是 PluginBase 的子类或实例')
                rec.module = module
                rec.instance = instance
                rec.context = PluginContext(self, rec)
                try:
                    instance.on_load(rec.context)
                except Exception as exc:
                    raise PluginError('on_load 失败: %s: %s' % (type(exc).__name__, exc))
                rec.loaded = True
                self._emit(name, '已加载: %s v%s（%s）' % (rec.display_name, rec.version, rec.path),
                           'success')
                return True
            except PluginError as exc:
                rec.error = str(exc)
            except Exception as exc:  # noqa: BLE001 - 插件代码不可信
                rec.error = '%s: %s' % (type(exc).__name__, exc)
                self._emit(name, traceback.format_exc().strip(), 'error')
            # 失败清理
            sys.modules.pop(mod_name, None)
            rec.loaded = False
            rec.instance = None
            rec.module = None
            rec.context = None
            self._emit(name, '加载失败: %s' % rec.error, 'error')
            return False

    def unload(self, name: str) -> bool:
        with self._lock:
            rec = self.records.get(name)
            if rec is None or (not rec.loaded and rec.instance is None):
                return False
            if rec.context is not None:
                rec.context.stop_event.set()
            try:
                if rec.instance is not None:
                    rec.instance.on_unload()
            except Exception as exc:  # noqa: BLE001
                self._emit(name, 'on_unload 异常: %s: %s' % (type(exc).__name__, exc), 'warn')
            sys.modules.pop(PLUGIN_MODULE_PREFIX + safe_name(name), None)
            rec.loaded = False
            rec.instance = None
            rec.module = None
            rec.context = None
            entry = self._running.get(name)
            if entry is not None and self._is_live(entry):
                # 这里不销账：账本只由线程自己的 finally 清。卸载时任务还在跑，
                # 说明它可能正卡在那台设备上；此时若把「执行中」抹掉，重新加载后
                # 就能起第二个任务，两条线程会在同一条串口/Modbus 连接上交错收发。
                # 旧任务的 context 仍在账本里，所以「停止」按钮照样能停它。
                self._emit(name, '卸载时仍有任务在跑，等它退出前不会再接受新请求', 'warn')
            return True

    def load_all(self) -> None:
        for name in self.names():
            if self.is_enabled(name):
                self.load(name)

    def reload(self, name: str) -> bool:
        self.unload(name)
        return self.load(name)

    def reload_all(self) -> None:
        for name in self.names():
            if self.is_enabled(name):
                self.reload(name)

    def shutdown(self) -> None:
        self._closed = True
        for name in self.names():
            try:
                self.unload(name)
            except Exception:
                pass

    # ---------------- 执行 ----------------
    def commands(self, name: str) -> List[Command]:
        rec = self.records.get(name)
        if rec is None or not rec.loaded or rec.instance is None:
            return []
        try:
            cmds = list(rec.instance.commands() or [])
        except Exception as exc:  # noqa: BLE001
            self._emit(name, '获取命令列表失败: %s: %s' % (type(exc).__name__, exc), 'error')
            return []
        out: List[Command] = []
        for c in cmds:
            if isinstance(c, Command):
                out.append(c)
            elif isinstance(c, (tuple, list)) and c:
                out.append(Command(label=str(c[0]), func=c[1], description=str(c[2]) if len(c) > 2 else ''))
        return out

    @staticmethod
    def _is_live(entry: Tuple[threading.Thread, 'PluginContext']) -> bool:
        """账本里这条占用还算不算数。

        `ident is None` 表示线程已登记但还没 start —— 这一刻 `is_alive()` 也是 False。
        只按 is_alive 判断的话，claim 与 start 之间这几微秒里任何一次 is_running
        都会把刚占上的名额当成「死了的脏记录」自愈掉，闸门静默失效；而 is_busy 是
        写进文档的公开接口，别的线程随时可能调进来。start 过之后 ident 恒不为 None，
        线程跑完也不会变回去，所以这个判断不会把真死了的任务永远留在账上。
        """
        t = entry[0]
        return t.is_alive() or t.ident is None

    def is_running(self, name: str) -> bool:
        with self._lock:
            entry = self._running.get(name)
            if entry is None:
                return False
            if self._is_live(entry):
                return True
            # 线程已经没了却没能走到 finally（解释器退出等极端情况）：
            # 顺手清掉，别让插件永远显示「执行中」并挡住后续请求。
            self._running.pop(name, None)
            return False

    def _claim(self, name: str, thread: threading.Thread,
               ctx: 'PluginContext') -> bool:
        """占住 name 的执行位；已经有活着的任务在跑就返回 False。

        「同一个插件同时只跑一个任务」这道闸以前只存在于 run_command，而面板上的
        按钮全走 run_async，压根不登记 —— 连点两次「扫描」就是两个 worker 在同一条
        Modbus/SSH 连接上交错收发，两份结果互相覆盖。现在两条入口共用同一本账，
        而且登记必须发生在调用方（起线程之前），否则两次快速请求都能通过检查。
        """
        with self._lock:
            busy = self._running.get(name)
            if busy is not None and busy[0] is not thread and self._is_live(busy):
                return False
            self._running[name] = (thread, ctx)
            return True

    def _release(self, name: str, thread: threading.Thread) -> None:
        """只归还自己那一份占用：插件被重载后，旧线程不该清掉新任务的登记。"""
        with self._lock:
            entry = self._running.get(name)
            if entry is not None and entry[0] is thread:
                self._running.pop(name, None)

    def run_command(self, name: str, index: int) -> bool:
        rec = self.records.get(name)
        if rec is None or not rec.loaded or rec.context is None:
            self._emit(name, '插件未加载，无法执行', 'error')
            return False
        cmds = self.commands(name)
        if not (0 <= index < len(cmds)):
            self._emit(name, '命令序号 %s 不存在' % index, 'error')
            return False
        cmd = cmds[index]
        ctx = rec.context

        def runner():
            self._emit(name, '▶ 开始执行: %s' % cmd.label, 'info')
            t0 = time.monotonic()
            try:
                cmd.func(ctx)
            except PluginError as exc:
                self._emit(name, '✖ %s' % exc, 'error')
            except Exception as exc:  # noqa: BLE001 - 插件代码不可信
                self._emit(name, '✖ 执行异常: %s: %s' % (type(exc).__name__, exc), 'error')
                self._emit(name, traceback.format_exc().strip(), 'error')
            else:
                self._emit(name, '✔ %s 完成 (%.2fs)' % (cmd.label, time.monotonic() - t0), 'success')
            finally:
                self._release(name, threading.current_thread())

        t = threading.Thread(target=runner, daemon=True, name='plugin-%s-cmd' % name)
        if not self._claim(name, t, ctx):
            self._emit(name, '上一个任务还在执行，本次请求已忽略（可点「停止」中断）', 'warn')
            return False
        ctx.stop_event.clear()
        return self._start_claimed(name, t)

    def _start_claimed(self, name: str, thread: threading.Thread) -> bool:
        """启动已经占好位的线程；起不来就把名额还回去。

        线程数或内存到上限时 start() 会抛，而此时名额已占上、runner 的 finally
        又根本不会执行 —— 不还回去的话这个插件从此不能再执行任何动作，
        界面上永远显示「执行中」，且没有任何报错。
        """
        try:
            thread.start()
        except Exception as exc:  # noqa: BLE001 - 起线程失败必须归还名额
            self._release(name, thread)
            self._emit(name, '任务启动失败: %s: %s' % (type(exc).__name__, exc), 'error')
            return False
        return True

    def stop_plugin(self, name: str) -> None:
        """请求停止该插件正在跑的任务。

        停止标志必须发给账本里那个任务的 context，不能发给 rec.context：卸载后
        rec.context 是 None（旧任务还占着执行位，按「停止」却什么都不会发生），
        重载后是新的一份（旧任务盯的是旧 event，永远收不到请求）。
        """
        with self._lock:
            entry = self._running.get(name)
        ctx = entry[1] if entry is not None else None
        rec = self.records.get(name)
        if ctx is None and rec is not None:
            ctx = rec.context
        if ctx is None:
            self._emit(name, '没有可停止的任务（插件未加载，也没有仍在执行的旧任务）', 'warn')
            return
        ctx.stop_event.set()
        self._emit(name, '⏹ 已请求停止（插件应在 host.sleep/循环里检查 host.stop_requested）', 'warn')

    # ---------------- 界面用汇总 ----------------
    def status_of(self, name: str) -> str:
        rec = self.records.get(name)
        if rec is None:
            return '不存在'
        if not self.is_enabled(name):
            return '已禁用'
        if rec.error:
            return '加载失败'
        if not rec.loaded:
            return '未加载'
        if self.is_running(name):
            return '执行中'
        return '运行中'

    def summary(self) -> List[Dict[str, Any]]:
        out = []
        for name in self.names():
            rec = self.records[name]
            out.append({
                'name': name,
                'display_name': rec.display_name,
                'version': rec.version,
                'description': rec.description,
                'author': rec.author,
                'requires': tuple(rec.requires),
                'status': self.status_of(name),
                'error': rec.error,
                'path': rec.path,
                'directory': rec.directory,
                'enabled': self.is_enabled(name),
                'default_enabled': rec.default_enabled,
                'shadowed': ' 、'.join(self.shadowed.get(name, [])),
                'loaded': rec.loaded,
                'running': self.is_running(name),
            })
        return out
