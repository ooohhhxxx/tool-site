# -*- coding: utf-8 -*-
"""Web UI 与 Python 业务内核之间的第一版桥接层（骨架）。

设计约束：
1. 不 import 主程序 —— `ssh_modbus_tool.py` 顶层会引入 tkinter 相关状态，
   骨架阶段只读它的源码常量，避免任何 GUI 副作用。
2. 不返回任何密码 / 私钥字段，连接记录一律脱敏。
3. 所有方法同步、无状态、可脱离窗口单测（见 test_bridge.py）。
4. 现在是骨架：终端/文件用 mock 数据；后续把业务层从主程序抽出来后，
   保持这些方法签名不变，只替换实现，前端不用改。
"""
from __future__ import annotations

import importlib.metadata as _meta
import os
import pathlib
import platform
import re
import sys
import threading
import time
import zipfile
from collections import deque

try:  # 作为 webui 包导入
    from .core import (ConfigStore, HistoryStore, ModbusService,
                       SerialService, SSHService, fail, ok)
except ImportError:  # 作为顶层模块导入（app.py / 单测）
    from core import (ConfigStore, HistoryStore, ModbusService,
                      SerialService, SSHService, fail, ok)

ROOT = pathlib.Path(__file__).resolve().parent.parent
TOOL_SRC = ROOT / 'ssh_modbus_tool.py'

# plugin_manager / plugin_api 在项目根目录，桥接层要能 import 到
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

# 插件 ModbusApi 的 kind 名 → 功能码
_MODBUS_READ_FUNCS = {'coil': 1, 'discrete': 2, 'holding': 3, 'input': 4}
_MODBUS_WRITE_FUNCS = {'coil': 1, 'coils': 1, 'holding': 3, 'holdings': 3}

_TERM_REPLIES = {
    'ls': 'app.log  config.ini  etc/  logs/  readme.txt',
    'pwd': '/home/root',
    'cat readme.txt': 'UltimateTool · Web UI 桥接骨架\n后端已连通，业务能力逐步接入',
    'uname -a': 'Linux host 5.15.0 #1 SMP x86_64 GNU/Linux',
    'df': 'Filesystem  Size  Used  Avail\n/dev/sda1   40G   18G   22G',
    'help': '可用模拟命令: ls / pwd / cat readme.txt / uname -a / df / clear / help',
}


def _pkg(name):
    try:
        return _meta.version(name)
    except _meta.PackageNotFoundError:
        return 'not installed'


def _version():
    """安装版/可移植包以 version.json 为准（Web UI 版独立发版号）；
    开发环境没有 version.json 时读主程序源码的 APP_VERSION。"""
    try:
        import json
        data = json.loads((ROOT / 'version.json').read_text(encoding='utf-8'))
        if data.get('version'):
            return str(data['version'])
    except Exception:
        pass
    try:
        src = TOOL_SRC.read_text(encoding='utf-8')
        m = re.search(r'^APP_VERSION\s*=\s*"([^"]+)"', src, re.M)
        if m:
            return m.group(1)
    except OSError:
        pass
    return 'unknown'


def _safe_extract(zf, dest):
    """按相对路径解压，挡掉 ../ 和绝对路径（zip slip）。返回解压文件数。"""
    dest = pathlib.Path(dest).resolve()
    count = 0
    for member in zf.infolist():
        if member.is_dir():
            continue
        raw = member.filename.replace('\\', '/')
        parts = [p for p in raw.split('/') if p not in ('', '.')]
        if not parts or '..' in parts or ':' in parts[0]:
            continue
        target = dest.joinpath(*parts)
        try:
            target.resolve().relative_to(dest)   # 必须在目标目录内
        except ValueError:
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        with zf.open(member) as src, open(target, 'wb') as out:
            out.write(src.read())
        count += 1
    return count


class BridgeAPI:
    """pywebview `js_api` 暴露给前端的方法集合。

    前端调用形式： `await window.pywebview.api.<method>(...)`
    所有返回值必须是可 JSON 序列化的普通对象。
    """

    def __init__(self, root=None):
        self.root = pathlib.Path(root) if root else ROOT
        self._ssh = None
        self._modbus = None
        self._serial = None
        self._plugins = None
        self._plugin_error = ''
        self._plugin_logs = deque(maxlen=200)
        self.window = None            # app.py 注入，用于文件对话框
        self._transfer = {'active': False, 'kind': '', 'name': '',
                          'done': 0, 'total': 0, 'ok': None, 'error': ''}

    # ---------- 插件 ----------
    def _plugin_log(self, name, msg, level='info'):
        try:
            self._plugin_logs.append({'ts': time.strftime('%H:%M:%S'),
                                      'name': str(name), 'msg': str(msg),
                                      'level': str(level)})
        except Exception:
            pass

    @property
    def plugins(self):
        """懒加载插件管理器；auto_load 会实例化插件（只读元信息，不执行命令）。"""
        if self._plugins is None:
            try:
                from plugin_manager import PluginManager
                self._plugins = PluginManager(app=self, log=self._plugin_log,
                                              auto_load=True)
            except Exception as exc:
                self._plugin_error = str(exc) or exc.__class__.__name__
                self._plugins = False
        return self._plugins if self._plugins else None

    def plugin_list(self):
        mgr = self.plugins
        if mgr is None:
            return fail('插件管理器不可用：' + (self._plugin_error or '未知原因'),
                        plugins=[], logs=[])
        try:
            mgr.discover()
            return ok(plugins=mgr.summary(), dirs=list(mgr.scanned_dirs),
                      logs=list(self._plugin_logs))
        except Exception as exc:
            return fail('扫描插件失败：' + (str(exc) or exc.__class__.__name__),
                        plugins=[], logs=list(self._plugin_logs))

    def plugin_commands(self, name):
        mgr = self.plugins
        if mgr is None:
            return fail('插件管理器不可用', commands=[])
        try:
            cmds = mgr.commands(str(name)) or []
            return ok(commands=[{
                'index': i,
                'label': str(getattr(c, 'label', '') or ''),
                'description': str(getattr(c, 'description', '') or ''),
            } for i, c in enumerate(cmds)])
        except Exception as exc:
            return fail('读取插件动作失败：' + (str(exc) or exc.__class__.__name__),
                        commands=[])

    def plugin_set_enabled(self, name, enabled):
        mgr = self.plugins
        if mgr is None:
            return fail('插件管理器不可用')
        try:
            ok_ = bool(mgr.set_enabled(str(name), bool(enabled)))
            return ok(enabled=ok_) if ok_ else fail('切换插件状态失败')
        except Exception as exc:
            return fail('切换插件状态失败：' + (str(exc) or exc.__class__.__name__))

    def plugin_reload(self):
        mgr = self.plugins
        if mgr is None:
            return fail('插件管理器不可用', plugins=[])
        try:
            mgr.reload_all()
            return ok(plugins=mgr.summary(), logs=list(self._plugin_logs))
        except Exception as exc:
            return fail('重载插件失败：' + (str(exc) or exc.__class__.__name__),
                        plugins=[])

    def plugin_run(self, name, index):
        """真正执行插件动作：PluginManager 在后台线程跑，异常进插件日志。"""
        mgr = self.plugins
        if mgr is None:
            return fail('插件管理器不可用')
        try:
            started = bool(mgr.run_command(str(name), int(index)))
        except Exception as exc:
            return fail('执行失败：' + (str(exc) or exc.__class__.__name__))
        if not started:
            return fail('动作未能启动（插件未加载、已禁用，或已有任务在跑）')
        return ok(started=True, name=str(name), index=int(index))

    def plugin_logs(self):
        return ok(logs=list(self._plugin_logs))

    # ---------- 配置快照 ----------
    def config_snapshot(self):
        """把配置整份给前端（配置里没有密码；密码在连接记录里）。"""
        store = ConfigStore()
        r = store.load()
        if not r['ok']:
            return fail(r['error'], data={}, backup=r.get('backup'))
        return ok(data=store.data, source=pathlib.Path(store.path).name,
                  backup=r.get('backup'))

    def config_set(self, section, key, value):
        """改一项并立即落盘（与主程序「改完就存」的行为一致）。"""
        store = ConfigStore()
        r = store.load()
        if not r['ok']:
            return fail(r['error'])
        store.set(section, key, value)
        saved = store.save()
        if not saved['ok']:
            return fail(saved['error'])
        return ok(section=section, key=key, value=value)

    @property
    def ssh(self):
        """懒加载：不开窗口、不连设备时不必付 paramiko 的导入成本。"""
        if self._ssh is None:
            self._ssh = SSHService()
        return self._ssh

    @property
    def modbus(self):
        if self._modbus is None:
            self._modbus = ModbusService()
        return self._modbus

    @property
    def serial(self):
        if self._serial is None:
            self._serial = SerialService()
        return self._serial

    def get_info(self):
        return {
            'name': '调试工具',
            'version': _version(),
            'mode': 'webui-skeleton',
            'backend': 'python ' + platform.python_version(),
            'webview': _pkg('pywebview'),
            'source': str(TOOL_SRC.name),
        }

    def app_check_update(self):
        """只检查不安装：读远端清单与当前版本比较。"""
        try:
            from host import check_update
        except ImportError:
            from .host import check_update
        return check_update(_version())

    def app_quit(self):
        """更新完成后让用户一键退出（下次启动就是新版本）。"""
        win = self.window
        if win is None:
            return fail('窗口未就绪')
        try:
            win.destroy()
        except Exception as exc:
            return fail('退出失败：' + (str(exc) or exc.__class__.__name__))
        return ok(quit=True)

    def app_update_apply(self):
        """下载增量包并覆盖 app/ —— 只动代码层，不碰 python/ 运行时和用户配置。

        返回后需要重启才生效（当前进程用的还是内存里的旧模块）。
        """
        r = self.app_check_update()
        if not r.get('ok'):
            return fail(r.get('error') or '检查更新失败')
        if not r.get('webui_has_update'):
            return fail('已是最新版本 v%s' % r.get('current'))
        url = str((r.get('webui') or {}).get('app_zip') or '')
        if not url:
            return fail('清单里没有增量包地址')

        import io
        import urllib.request
        try:
            req = urllib.request.Request(url, headers={
                'User-Agent': 'UltimateTool-WebUI', 'Cache-Control': 'no-cache'})
            with urllib.request.urlopen(req, timeout=60) as resp:
                raw = resp.read()
        except Exception as exc:
            return fail('下载失败：' + (str(exc) or exc.__class__.__name__))

        try:
            with zipfile.ZipFile(io.BytesIO(raw)) as zf:
                count = _safe_extract(zf, self.root)
        except Exception as exc:
            return fail('解压失败：' + (str(exc) or exc.__class__.__name__))
        return ok(updated=count, version=r.get('webui_version'), size=len(raw),
                  restart=True, note='已更新，关闭后重新打开即可')

    def health(self):
        """依赖体检：确认打包时该带哪些库。"""
        return {n: _pkg(n) for n in
                ('pywebview', 'paramiko', 'pymodbus', 'pyserial', 'Pillow', 'pystray')}

    def echo(self, text=''):
        """双向通信自检：前端发什么就原样回什么，带服务端时间戳。"""
        return {'ok': True, 'echo': str(text), 'server_time': time.strftime('%H:%M:%S')}

    def list_hosts(self):
        """脱敏的连接记录：走业务内核 HistoryStore，只给 host / port / user。"""
        return HistoryStore().load()

    def get_config(self, section, key, default=None):
        """读一项配置（走业务内核 ConfigStore，不碰主程序 GUI 对象）。"""
        store = ConfigStore()
        r = store.load()
        if not r['ok']:
            return {'ok': False, 'error': r['error'], 'value': default}
        return {'ok': True, 'value': store.get(section, key, default)}

    def list_config_sections(self):
        """列出配置的顶层分组名，供前端设置页动态生成。"""
        store = ConfigStore()
        r = store.load()
        if not r['ok']:
            return {'ok': False, 'error': r['error'], 'sections': []}
        return {'ok': True, 'sections': sorted(k for k in store.data
                                                if isinstance(store.data.get(k), dict))}

    def run_command(self, cmd):
        """终端命令：已连接时走真实 SSH，否则保持原型 mock（前端签名不变）。

        返回始终带 'output'，前端不用区分真实/演示模式；'real' 标记供调试。
        """
        cmd = str(cmd or '').strip()
        if self.ssh.connected:
            r = self.ssh.exec_command(cmd)
            if not r['ok']:
                return {'ok': False, 'output': r['error'], 'error': r['error'], 'real': True}
            if cmd == 'clear':
                return {'ok': True, 'output': '', 'clear': True, 'real': True}
            return {'ok': True, 'output': r['stdout'], 'stderr': r['stderr'],
                    'exit_status': r['exit_status'], 'real': True}
        if cmd == 'clear':
            return {'ok': True, 'output': '', 'clear': True, 'real': False}
        if not cmd:
            return {'ok': True, 'output': '', 'real': False}
        if cmd in _TERM_REPLIES:
            return {'ok': True, 'output': _TERM_REPLIES[cmd], 'real': False}
        return {'ok': False, 'output': 'command not found: ' + cmd, 'real': False}

    # ---------- 真实 SSH 能力（前端接上连接 UI 后即可用）----------
    def ssh_connect(self, options=None):
        """传单个对象，避免密码出现在参数列表里：{host, port, user, password, key_path}。"""
        o = options if isinstance(options, dict) else {}
        r = self.ssh.connect(
            host=o.get('host'), port=o.get('port', 22), user=o.get('user'),
            password=o.get('password'), key_path=o.get('key_path'),
            timeout=o.get('timeout', 10), encoding=o.get('encoding', 'utf-8'))
        # 双保险：连接结果里绝不能带凭据
        return {k: v for k, v in r.items() if k not in ('password', 'key_path')}

    def ssh_disconnect(self):
        return self.ssh.disconnect()

    def ssh_status(self):
        return self.ssh.status()

    def ssh_exec(self, cmd, timeout=15):
        return self.ssh.exec_command(cmd, timeout=timeout)

    def ssh_list_dir(self, path='/'):
        return self.ssh.list_dir(path)

    # ---------- 交互式终端 ----------
    def ssh_open_shell(self, cols=80, rows=24):
        return self.ssh.open_shell(width=cols, height=rows)

    def ssh_shell_write(self, data):
        return self.ssh.shell_write(data)

    def ssh_shell_poll(self):
        return self.ssh.shell_poll()

    def ssh_shell_resize(self, cols, rows):
        return self.ssh.resize_shell(cols, rows)

    def ssh_shell_close(self):
        return self.ssh.close_shell()

    # ---------- 文件对话框 ----------
    def pick_file(self):
        if self.window is None:
            return fail('窗口未就绪', path='')
        try:
            import webview
            res = self.window.create_file_dialog(webview.OPEN_DIALOG, allow_multiple=False)
        except Exception as exc:
            return fail('打开文件对话框失败：' + (str(exc) or exc.__class__.__name__), path='')
        if not res:
            return ok(path='', cancelled=True)
        first = res[0] if isinstance(res, (list, tuple)) else res
        return ok(path=str(first))

    def pick_save_path(self, default_name=''):
        if self.window is None:
            return fail('窗口未就绪', path='')
        try:
            import webview
            res = self.window.create_file_dialog(
                webview.SAVE_DIALOG, save_filename=str(default_name or ''))
        except Exception as exc:
            return fail('打开保存对话框失败：' + (str(exc) or exc.__class__.__name__), path='')
        if not res:
            return ok(path='', cancelled=True)
        first = res[0] if isinstance(res, (list, tuple)) else res
        return ok(path=str(first))

    # ---------- 后台传输 ----------
    def _progress(self, done, total):
        self._transfer['done'] = int(done or 0)
        self._transfer['total'] = int(total or 0)

    def _run_transfer(self, kind, name, task):
        # 传输必须放后台线程：一次 100MB 上传卡住 UI 就废了
        self._transfer.update({'active': True, 'kind': kind, 'name': name,
                               'done': 0, 'total': 0, 'ok': None, 'error': ''})

        def worker():
            try:
                r = task()
            except Exception as exc:
                r = fail(str(exc) or exc.__class__.__name__)
            self._transfer.update({
                'active': False,
                'ok': bool(r.get('ok')),
                'error': '' if r.get('ok') else str(r.get('error') or '传输失败'),
            })

        threading.Thread(target=worker, daemon=True, name='transfer').start()

    def ssh_upload(self, local_path, remote_dir):
        if not self.ssh.connected:
            return fail('SSH 未连接')
        local_path = str(local_path or '')
        if not os.path.isfile(local_path):
            return fail('本地文件不存在')
        name = os.path.basename(local_path)
        if not name:
            return fail('无法确定文件名')
        remote = (str(remote_dir or '/').rstrip('/')) + '/' + name
        self._run_transfer('upload', name,
                           lambda: self.ssh.upload(local_path, remote, self._progress))
        return ok(started=True, name=name, remote=remote)

    def ssh_download(self, remote_path, local_path):
        if not self.ssh.connected:
            return fail('SSH 未连接')
        remote_path = str(remote_path or '').strip()
        if not remote_path:
            return fail('远端路径为空')
        if not str(local_path or '').strip():
            return fail('保存路径为空')
        name = remote_path.rstrip('/').split('/')[-1] or 'download.bin'
        self._run_transfer('download', name,
                           lambda: self.ssh.download(remote_path, str(local_path),
                                                     self._progress))
        return ok(started=True, name=name, local=str(local_path))

    def transfer_status(self):
        return ok(**self._transfer)

    # ===== 插件宿主 API =====
    # plugin_manager 通过 getattr(app, 'api_xxx') 调用这些方法。
    # 插件侧约定：失败必须抛异常（由 PluginContext 转成插件日志），成功返回裸值。
    def api_ssh_connected(self):
        return bool(self.ssh.connected)

    def api_ssh_cwd(self):
        return '/'

    def api_ssh_exec(self, cmd, timeout=15):
        r = self.ssh.exec_command(cmd, timeout=timeout)
        if not r['ok']:
            raise RuntimeError(r['error'])
        return (r['exit_status'], r['stdout'], r['stderr'])

    def api_sftp_listdir(self, path=None):
        r = self.ssh.list_dir(path or '/')
        if not r['ok']:
            raise RuntimeError(r['error'])
        return [{'name': x['name'], 'size': x['size'], 'mtime': x['mtime'],
                 'is_dir': x['dir']} for x in r['rows']]

    def api_sftp_stat(self, path):
        r = self.ssh.stat(path)
        if not r['ok']:
            raise RuntimeError(r['error'])
        return {'name': r['name'], 'size': r['size'], 'mtime': r['mtime'],
                'is_dir': r['dir']}

    def api_sftp_read_text(self, path, encoding='utf-8'):
        r = self.ssh.read_text(path, encoding)
        if not r['ok']:
            raise RuntimeError(r['error'])
        return r['text']

    def api_sftp_write_text(self, path, text, encoding='utf-8'):
        r = self.ssh.write_text(path, text, encoding)
        if not r['ok']:
            raise RuntimeError(r['error'])

    def api_sftp_upload(self, local, remote, callback=None):
        r = self.ssh.upload(local, remote, callback)
        if not r['ok']:
            raise RuntimeError(r['error'])

    def api_sftp_download(self, remote, local, callback=None):
        r = self.ssh.download(remote, local, callback)
        if not r['ok']:
            raise RuntimeError(r['error'])

    def api_modbus_connected(self):
        return bool(self.modbus.connected)

    def api_modbus_read(self, kind, addr, count=1):
        func = _MODBUS_READ_FUNCS.get(str(kind).lower())
        if func is None:
            raise ValueError('不支持的读取类型：' + str(kind))
        r = self.modbus.read(func, addr, count)
        if not r['ok']:
            raise RuntimeError(r['error'])
        return r['values']

    def api_modbus_write(self, kind, addr, value):
        func = _MODBUS_WRITE_FUNCS.get(str(kind).lower())
        if func is None:
            raise ValueError('不支持的写入类型：' + str(kind))
        r = self.modbus.write(func, addr, value)
        if not r['ok']:
            raise RuntimeError(r['error'])
        return True

    def api_serial_connected(self):
        return bool(self.serial.connected)

    def api_serial_ports(self):
        r = self.serial.list_ports()
        return [str(p['device']) for p in r.get('ports', [])]

    def api_serial_send(self, data):
        r = self.serial.send(bytes(data or b''))
        if not r['ok']:
            raise RuntimeError(r['error'])

    def api_serial_send_str(self, text):
        r = self.serial.send(str(text or ''))
        if not r['ok']:
            raise RuntimeError(r['error'])

    def api_serial_read(self, timeout=0.5):
        r = self.serial.read_bytes(timeout)
        if not r['ok']:
            raise RuntimeError(r['error'])
        return r['data']

    def api_serial_flush(self):
        self.serial.take(1000)

    # ---------- 连接记录 ----------
    def history_remove(self, host, port=None, user=None):
        """删一条连接记录（只动 JSON，不碰已连接的会话）。"""
        store = HistoryStore()
        loaded = store.load()
        if not loaded['ok'] and not loaded.get('source'):
            return fail(loaded.get('error') or '连接记录文件读取失败')
        return store.remove(host, port, user)

    def history_add(self, host, port, user):
        """只存 host/port/user —— 密码不写入记录（安全优先）。"""
        host, user = str(host or '').strip(), str(user or '').strip()
        if not host or not user:
            return fail('主机和用户名不能为空')
        store = HistoryStore()
        loaded = store.load()
        if not loaded['ok'] and not loaded.get('source'):
            return fail(loaded.get('error') or '连接记录文件读取失败')
        r = store.add(host, port or '22', user)
        if not r['ok']:
            return fail(r['error'])
        return ok(host=host, port=str(port or '22'), user=user,
                  note='已保存，但密码不写入记录，下次连接需重新输入')

    def list_files(self, path='/'):
        """文件列表（骨架阶段为 mock，签名与将来真实 SFTP 保持一致）。"""
        rows = [
            {'name': 'etc/', 'size': '', 'mtime': '11-04 09:20', 'dir': True},
            {'name': 'logs/', 'size': '', 'mtime': '11-03 18:40', 'dir': True},
            {'name': 'app.log', 'size': '1.2 MB', 'mtime': '11-04 10:22', 'dir': False},
            {'name': 'readme.txt', 'size': '1.2 KB', 'mtime': '11-03 14:10', 'dir': False},
        ]
        return {'ok': True, 'path': str(path or '/'), 'rows': rows}

    # ---------- 真实 Modbus 能力 ----------
    def modbus_connect(self, options=None):
        o = options if isinstance(options, dict) else {}
        return self.modbus.connect(host=o.get('host'), port=o.get('port', 502),
                                   timeout=o.get('timeout', 3))

    def modbus_disconnect(self):
        return self.modbus.disconnect()

    def modbus_status(self):
        return self.modbus.status()

    def modbus_read(self, func, addr, count=1):
        return self.modbus.read(func, addr, count)

    def modbus_write(self, func, addr, value):
        return self.modbus.write(func, addr, value)

    def modbus_poll(self, points):
        return self.modbus.poll(points)

    # ---------- 真实串口能力 ----------
    def serial_list_ports(self):
        return self.serial.list_ports()

    def serial_connect(self, options=None):
        o = options if isinstance(options, dict) else {}
        return self.serial.connect(
            port=o.get('port'), baudrate=o.get('baudrate', 115200),
            bytesize=o.get('bytesize', 8), parity=o.get('parity', 'None'),
            stopbits=o.get('stopbits', '1'), timeout=o.get('timeout', 0.5),
            encoding=o.get('encoding', 'utf-8'))

    def serial_disconnect(self):
        return self.serial.disconnect()

    def serial_send(self, payload, hex_mode=False, newline=False):
        return self.serial.send(payload, hex_mode=hex_mode, newline=newline)

    def serial_stats(self):
        return self.serial.stats()

    def serial_take(self, max_items=100):
        return self.serial.take(max_items)

    def serial_start_receive(self):
        """启动内核接收线程；前端随后轮询 serial_take 取数据。"""
        return self.serial.start_receive()

    def serial_reset_decoder(self, encoding='utf-8'):
        return {'ok': True, 'encoding': self.serial.reset_decoder(encoding)}
