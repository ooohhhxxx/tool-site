# -*- coding: utf-8 -*-
"""Web UI 版的宿主能力：单实例、DPI 感知、更新检查。

这里刻意不 import 主程序：
- 单实例用同一套互斥体逻辑（Global\\ + 183/5 两种"已存在"判定）
- DPI 用 per-monitor v2（WebView2 比 Tk 更需要它）
- 更新检查只读远端清单比较版本号，不下载、不安装
"""
from __future__ import annotations

import json
import ctypes
import sys
import time
import urllib.request
from urllib.error import URLError

MANIFEST_URL = 'https://ooohhhxxx.github.io/tool-site/version.json'
_ERROR_ALREADY_EXISTS = 183
_ERROR_ACCESS_DENIED = 5


class SingleInstance:
    """同名互斥体保护：机器级（Global\\），跨用户也能判出来。"""

    def __init__(self, name='Global\\UltimateTool_WebUI'):
        self.name = name
        self.handle = None
        self.message = ''

    def acquire(self):
        """True = 可以继续启动；False = 已有实例（原因在 self.message）。"""
        if sys.platform != 'win32':
            return True
        try:
            k = ctypes.windll.kernel32
            k.CreateMutexW.restype = ctypes.c_void_p
            k.CreateMutexW.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_wchar_p]
            handle = k.CreateMutexW(None, False, self.name)
            err = k.GetLastError()
            if not handle:
                if err == _ERROR_ACCESS_DENIED:
                    self.message = ('另一个登录会话或另一个 Windows 用户'
                                    '已经打开了本工具。')
                    return False
                # 其它未知失败：宁可让用户打开，也不要因为拿不到互斥体就打不开
                return True
            self.handle = handle
            if err == _ERROR_ALREADY_EXISTS:
                self.message = '已经有一个本工具的窗口在运行。'
                return False
            return True
        except Exception:
            return True


def enable_dpi_awareness():
    """per-monitor v2 → 系统级 → 老接口，逐级回退。"""
    if sys.platform != 'win32':
        return
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
        return
    except Exception:
        pass
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
        return
    except Exception:
        pass
    try:
        ctypes.windll.user32.SetProcessDPIAware()
    except Exception:
        pass


def version_tuple(text):
    """'1.6.7' → (1, 6, 7)；遇到非数字段按 0 处理，永不抛。"""
    parts = []
    for chunk in str(text or '').strip().split('.'):
        digits = ''.join(ch for ch in chunk if ch.isdigit())
        parts.append(int(digits) if digits else 0)
    return tuple(parts) if parts else (0,)


def check_update(current_version, url=None, timeout=8):
    """只检查：读清单比较版本，不下载不安装。"""
    url = url or MANIFEST_URL
    try:
        req = urllib.request.Request(url, headers={
            'User-Agent': 'UltimateTool-WebUI', 'Cache-Control': 'no-cache'})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read()
    except (URLError, OSError, ValueError) as exc:
        return {'ok': False, 'error': '检查更新失败：' + str(exc),
                'current': str(current_version), 'latest': '', 'has_update': False}
    try:
        data = json.loads(raw.decode('utf-8-sig'))
    except ValueError as exc:
        return {'ok': False, 'error': '清单格式不对：' + str(exc),
                'current': str(current_version), 'latest': '', 'has_update': False}

    latest = str(data.get('version') or '')
    if not latest:
        return {'ok': False, 'error': '清单里没有 version 字段',
                'current': str(current_version), 'latest': '', 'has_update': False}
    has_update = version_tuple(latest) > version_tuple(current_version)
    webui = data.get('webui') or {}
    webui_version = str(webui.get('version') or '')
    return {
        'ok': True,
        'current': str(current_version),
        'latest': latest,
        'has_update': has_update,
        'date': str(data.get('date') or ''),
        'notes': str(data.get('notes') or ''),
        'url': str(data.get('url') or ''),
        'checked_at': time.strftime('%H:%M:%S'),
        # Web UI 版独立版本号（和 Tk 版解耦，两边可以各自发版）
        'webui': webui,
        'webui_version': webui_version,
        'webui_has_update': bool(webui_version) and
                            version_tuple(webui_version) > version_tuple(current_version),
    }


def show_message(title, text):
    """没有窗口时也能提示（单实例冲突发生在 window 创建之前）。"""
    if sys.platform != 'win32':
        print(f'{title}: {text}', file=sys.stderr)
        return
    try:
        ctypes.windll.user32.MessageBoxW(None, str(text), str(title), 0x40)
    except Exception:
        print(f'{title}: {text}', file=sys.stderr)
