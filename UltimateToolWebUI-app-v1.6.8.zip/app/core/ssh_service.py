# -*- coding: utf-8 -*-
"""SSH / SFTP 业务内核：无 GUI 依赖的 paramiko 封装。

对齐主程序里踩过的坑（行为不能因为换 UI 而变）：
1. `open_sftp()` 必须单独 try。交换机/工控机常没装 sftp-server，
   会抛 "EOF during negotiation"，但 SSH 终端完全能用 —— 不能判整条连接失败。
2. exec 的 stdout / stderr 必须并行读，只读一路会在另一路写满缓冲时死锁；
   exec 通道用完必须显式 close，否则插件反复执行会堆僵尸通道。
3. 命令按链路编码编成 bytes 再发，paramiko 收到 str 会写死按 UTF-8 编码。
4. 结果一律脱敏：password / key_path 不出现在任何返回值里。

所有方法返回 contract.ok / contract.fail 形式的 dict，异常不外泄。
"""
from __future__ import annotations

import os
import stat
import threading

import paramiko

from .contract import fail, ok


class TransferCancelled(Exception):
    """进度回调里抛出，用来中断 put/get。"""


class SSHService:
    def __init__(self):
        self.client = None
        self.sftp = None
        self.sftp_error = None
        self.encoding = 'utf-8'
        self.connected = False
        self.cancel = threading.Event()
        self._peer = {'host': '', 'port': 22, 'user': ''}
        self.chan = None                 # 交互式 shell 通道
        self._shell_buf = bytearray()    # 尚未被前端取走的输出

    # ---------- 连接 ----------
    def connect(self, host, port=22, user='', password=None, key_path=None,
                timeout=10, encoding='utf-8'):
        host, user = str(host or '').strip(), str(user or '').strip()
        if not host:
            return fail('主机不能为空')
        if not user:
            return fail('用户名不能为空')
        try:
            port = int(port)
        except (TypeError, ValueError):
            return fail('端口必须是数字')
        if not 1 <= port <= 65535:
            return fail('端口超出范围（1~65535）')
        if not password and not key_path:
            return fail('请输入密码，或指定私钥文件')
        self.cancel.clear()

        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        try:
            client.connect(
                hostname=host, port=port, username=user,
                password=password or None, key_filename=key_path or None,
                timeout=timeout, banner_timeout=timeout, auth_timeout=timeout,
                allow_agent=False, look_for_keys=False)
        except Exception as exc:
            try:
                client.close()
            except Exception:
                pass
            return fail('连接失败：' + (str(exc) or exc.__class__.__name__))

        if self.cancel.is_set():
            client.close()
            return fail('连接已取消')

        try:
            transport = client.get_transport()
            if transport:
                transport.set_keepalive(30)
        except Exception:
            pass

        # SFTP 单独兜底：拿不到子系统不算连接失败，终端/命令照常可用
        sftp, sftp_error = None, None
        try:
            sftp = client.open_sftp()
        except Exception as exc:
            sftp_error = str(exc) or exc.__class__.__name__

        self.client, self.sftp, self.sftp_error = client, sftp, sftp_error
        self.encoding, self.connected = str(encoding or 'utf-8'), True
        self._peer = {'host': host, 'port': port, 'user': user}
        return ok(**self.status())

    def disconnect(self):
        self.close_shell()
        for obj in (self.sftp, self.client):
            if obj is not None:
                try:
                    obj.close()
                except Exception:
                    pass
        self.sftp = self.client = None
        self.sftp_error = None
        self.connected = False
        return ok(connected=False)

    def status(self):
        return {'connected': bool(self.connected), 'sftp': self.sftp is not None,
                'sftp_error': self.sftp_error, 'encoding': self.encoding,
                'host': self._peer['host'], 'port': self._peer['port'],
                'user': self._peer['user']}

    # ---------- 命令 ----------
    def exec_command(self, cmd, timeout=15):
        if not self.connected or self.client is None:
            return fail('SSH 未连接')
        cmd = str(cmd or '')
        if not cmd.strip():
            return ok(exit_status=0, stdout='', stderr='')
        try:
            raw = cmd.encode(self.encoding, errors='replace')
        except LookupError:
            raw = cmd.encode('utf-8', errors='replace')

        sink = {'out': [], 'err': []}

        def drain(stream, key):
            try:
                while True:
                    chunk = stream.read(32768)
                    if not chunk:
                        break
                    sink[key].append(chunk)
            except Exception:
                pass

        try:
            _in, stdout, stderr = self.client.exec_command(raw, timeout=timeout)
            err_thread = threading.Thread(target=drain, args=(stderr, 'err'),
                                          daemon=True, name='ssh-exec-stderr')
            err_thread.start()
            try:
                drain(stdout, 'out')
                err_thread.join(max(1.0, float(timeout)))
                rc = stdout.channel.recv_exit_status()
            finally:
                try:
                    stdout.channel.close()
                except Exception:
                    pass
            return ok(exit_status=rc,
                      stdout=b''.join(sink['out']).decode(self.encoding, errors='replace'),
                      stderr=b''.join(sink['err']).decode(self.encoding, errors='replace'))
        except Exception as exc:
            return fail('命令执行失败：' + (str(exc) or exc.__class__.__name__))

    # ---------- 交互式 shell ----------
    def open_shell(self, term='xterm-256color', width=80, height=24):
        if not self.connected or self.client is None:
            return fail('SSH 未连接')
        try:
            chan = self.client.invoke_shell(term=term, width=int(width), height=int(height))
            chan.settimeout(0.0)     # 非阻塞：poll 里用 recv_ready 判断，不靠超时
        except Exception as exc:
            return fail('打开终端失败：' + (str(exc) or exc.__class__.__name__))
        self.chan = chan
        self._shell_buf.clear()
        return ok(open=True, **self.status())

    def shell_write(self, data):
        """前端按键 → 远端。str 按链路编码编，bytes 原样发。"""
        chan = self.chan
        if chan is None or getattr(chan, 'closed', False):
            return fail('终端未打开')
        try:
            payload = data if isinstance(data, (bytes, bytearray)) else \
                str(data).encode(self.encoding, errors='replace')
        except LookupError:
            payload = str(data).encode('utf-8', errors='replace')
        try:
            chan.send(payload)
            return ok(bytes_sent=len(payload))
        except Exception as exc:
            return fail('发送失败：' + (str(exc) or exc.__class__.__name__))

    def shell_poll(self):
        """取走终端输出。bytes 用 base64 过 UI 边界，前端交给 xterm 直接写。"""
        import base64
        chan = self.chan
        if chan is None:
            return fail('终端未打开', data='', open=False)
        chunk = b''
        try:
            while chan.recv_ready():
                piece = chan.recv(65536)
                if not piece:
                    break
                self._shell_buf += piece
                if len(self._shell_buf) >= 262144:   # 单轮上限，防止前端卡死
                    break
            chunk = bytes(self._shell_buf)
            self._shell_buf.clear()
        except Exception:
            # recv 期间通道被关是正常收尾，不算错误
            pass
        is_open = not getattr(chan, 'closed', False)
        return ok(data=base64.b64encode(chunk).decode('ascii'),
                  nbytes=len(chunk), open=is_open)

    def resize_shell(self, width, height):
        chan = self.chan
        if chan is None:
            return fail('终端未打开')
        try:
            chan.resize_pty(width=int(width), height=int(height))
            return ok(width=int(width), height=int(height))
        except Exception as exc:
            return fail('调整终端尺寸失败：' + (str(exc) or exc.__class__.__name__))

    def close_shell(self):
        chan, self.chan = self.chan, None
        self._shell_buf.clear()
        if chan is not None:
            try:
                chan.close()
            except Exception:
                pass
        return ok(open=False)

    # ---------- SFTP ----------
    def list_dir(self, path='/'):
        if self.sftp is None:
            return fail('SFTP 不可用（设备可能没装 sftp-server）', rows=[],
                        sftp_error=self.sftp_error)
        try:
            rows = []
            for a in self.sftp.listdir_attr(path):
                mode = getattr(a, 'st_mode', 0) or 0
                rows.append({
                    'name': str(getattr(a, 'filename', '') or ''),
                    'size': int(getattr(a, 'st_size', 0) or 0),
                    'mtime': int(getattr(a, 'st_mtime', 0) or 0),
                    'dir': bool(stat.S_ISDIR(mode)),
                })
            return ok(path=str(path), rows=rows)
        except Exception as exc:
            return fail('读取目录失败：' + (str(exc) or exc.__class__.__name__), rows=[])

    def upload(self, local_path, remote_path, progress=None):
        if self.sftp is None:
            return fail('SFTP 不可用')
        if not os.path.isfile(local_path):
            return fail('本地文件不存在：' + str(local_path))

        def cb(done, total):
            if self.cancel.is_set():
                raise TransferCancelled()
            if progress:
                try:
                    progress(done, total)
                except Exception:
                    pass

        try:
            self.sftp.put(local_path, remote_path, callback=cb)
        except TransferCancelled:
            return fail('上传已取消')
        except Exception as exc:
            return fail('上传失败：' + (str(exc) or exc.__class__.__name__))
        return ok(local=local_path, remote=remote_path)

    def download(self, remote_path, local_path, progress=None):
        if self.sftp is None:
            return fail('SFTP 不可用')

        def cb(done, total):
            if self.cancel.is_set():
                raise TransferCancelled()
            if progress:
                try:
                    progress(done, total)
                except Exception:
                    pass

        try:
            self.sftp.get(remote_path, local_path, callback=cb)
        except TransferCancelled:
            return fail('下载已取消')
        except Exception as exc:
            return fail('下载失败：' + (str(exc) or exc.__class__.__name__))
        return ok(remote=remote_path, local=local_path)

    def stat(self, path):
        """远端路径属性：内核没有裸 stat，从父目录列表里找（插件读文件前常用）。"""
        if self.sftp is None:
            return fail('SFTP 不可用')
        p = str(path or '/')
        parent = p.rsplit('/', 1)[0] or '/'
        name = p.rstrip('/').rsplit('/', 1)[-1]
        if not name:
            parent, name = '/', ''
        r = self.list_dir(parent)
        if not r['ok']:
            return r
        for row in r['rows']:
            if row['name'] == name:
                return ok(**row)
        return fail('路径不存在：' + p)

    def read_text(self, path, encoding='utf-8'):
        if self.sftp is None:
            return fail('SFTP 不可用')
        try:
            with self.sftp.open(str(path), 'r') as f:
                raw = f.read()
        except Exception as exc:
            return fail('读取失败：' + (str(exc) or exc.__class__.__name__))
        try:
            return ok(text=bytes(raw).decode(encoding or 'utf-8', errors='replace'))
        except LookupError:
            return ok(text=bytes(raw).decode('utf-8', errors='replace'))

    def write_text(self, path, text, encoding='utf-8'):
        if self.sftp is None:
            return fail('SFTP 不可用')
        try:
            data = str(text).encode(encoding or 'utf-8', errors='replace')
        except LookupError:
            data = str(text).encode('utf-8', errors='replace')
        try:
            with self.sftp.open(str(path), 'w') as f:
                f.write(data)
        except Exception as exc:
            return fail('写入失败：' + (str(exc) or exc.__class__.__name__))
        return ok(path=str(path), nbytes=len(data))
