# -*- coding: utf-8 -*-
"""Web UI 的业务内核（无 GUI 依赖）。

第一步：配置与连接记录。后续 SSH / Modbus / 串口按同样方式逐块抽入，
每个模块只依赖 paramiko / pymodbus / pyserial，不碰 tkinter。
"""
from .config import ConfigStore, atomic_write_json
from .contract import PUBLIC_HOST_FIELDS, assert_public, fail, ok, public_host
from .history import MAX_HISTORY, HistoryStore
from .modbus_service import ModbusService
from .serial_service import SerialService, normalise_port
from .ssh_service import SSHService, TransferCancelled

__all__ = [
    'ConfigStore', 'atomic_write_json', 'HistoryStore', 'MAX_HISTORY',
    'ModbusService', 'SerialService', 'normalise_port',
    'SSHService', 'TransferCancelled',
    'ok', 'fail', 'public_host', 'assert_public', 'PUBLIC_HOST_FIELDS',
]
