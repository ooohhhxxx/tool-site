# -*- coding: utf-8 -*-
"""业务内核 ↔ UI 的数据契约。

所有 core 方法统一返回 Result 字典，前端只依赖这里的字段名，
不依赖 `ssh_modbus_tool.py` 的任何内部对象（那些是 Tk 控件，迁移后必然消失）。

约定：
    {'ok': bool, ...}          失败时必须带 'error'（人话，可直接展示）
    连接记录对外只暴露 PUBLIC_HOST_FIELDS，密码/私钥字段绝不跨过这层边界
"""
from __future__ import annotations

PUBLIC_HOST_FIELDS = ('host', 'port', 'user')
SECRET_FIELDS = frozenset({'password', 'enc', 'key', 'key_path', 'private_key'})


def ok(**fields):
    return {'ok': True, **fields}


def fail(message, **fields):
    return {'ok': False, 'error': str(message), **fields}


def public_host(item):
    """把一条内部记录脱敏成可跨边界传输的字典。"""
    if not isinstance(item, dict):
        return None
    return {
        'host': str(item.get('host') or ''),
        'port': str(item.get('port') or ''),
        'user': str(item.get('user') or item.get('username') or ''),
    }


def assert_public(result):
    """契约自检：确保返回里没有任何敏感字段（测试里用）。"""
    for host in result.get('hosts', []):
        if set(host.keys()) - set(PUBLIC_HOST_FIELDS):
            return False
        if SECRET_FIELDS & set(host.keys()):
            return False
    return True
