# -*- coding: utf-8 -*-
"""Modbus TCP 业务内核：纯 pymodbus，无 GUI 依赖。

对齐主程序踩过的坑：
1. pymodbus >= 3.7 的 `read_*(addr, count)` 里 count 是 keyword-only，
   必须写 `count=n`；老版本是位置参数。按版本自动切。
2. FC02 离散输入 / FC04 输入寄存器是**只读区**，写它们会落到同地址的
   线圈/保持寄存器上，读的和写的不是同一个数 —— 当场拦下。
3. 设备拒绝请求时 `resp.isError()` 为真，不能拿异常响应当正常值。
4. 后台轮询任务必须绑定派发那一刻的 client（连接代次），
   断开重连之间排队的旧任务不能掉到新连接上。

所有方法返回 contract.ok / fail 形式的 dict。
"""
from __future__ import annotations

import threading

try:
    import pymodbus
    from pymodbus.client import ModbusTcpClient

    _parts = [int(x) for x in str(getattr(pymodbus, '__version__', '0')).split('.')[:2]
              if x.isdigit()]
    MB_COUNT_KW = tuple(_parts) >= (3, 7) if len(_parts) >= 2 else True
except Exception:  # 缺库时给个明确错误，不让 NameError 冒到界面
    ModbusTcpClient = None
    MB_COUNT_KW = True

from .contract import fail, ok  # noqa: E402

READ_METHODS = {
    1: 'read_coils',
    2: 'read_discrete_inputs',
    3: 'read_holding_registers',
    4: 'read_input_registers',
}
WRITE_METHODS = {
    1: 'write_coil',
    3: 'write_register',
}
READONLY_FUNCS = (2, 4)


class ModbusService:
    def __init__(self):
        self.client = None
        self.connected = False
        self.peer = {'host': '', 'port': 502, 'timeout': 3}
        self.seq = 0                 # 连接代次，防止旧任务写进新连接
        self._lock = threading.Lock()

    def connect(self, host, port=502, timeout=3):
        host = str(host or '').strip()
        if not host:
            return fail('IP / 主机不能为空')
        try:
            port, timeout = int(port), float(timeout)
        except (TypeError, ValueError):
            return fail('端口和超时必须是数字')
        if not 1 <= port <= 65535:
            return fail('端口超出范围（1~65535）')
        if timeout <= 0:
            return fail('超时必须大于 0')
        if ModbusTcpClient is None:
            return fail('未安装 pymodbus 库')

        client = ModbusTcpClient(host=host, port=port, timeout=timeout)
        try:
            opened = client.connect()
            if opened is False:
                client.close()
                return fail('连接失败：设备未响应')
        except Exception as exc:
            try:
                client.close()
            except Exception:
                pass
            return fail('连接失败：' + (str(exc) or exc.__class__.__name__))

        with self._lock:
            self.seq += 1
            self.client, self.connected = client, True
            self.peer = {'host': host, 'port': port, 'timeout': timeout}
        return ok(**self.status())

    def disconnect(self):
        with self._lock:
            client, self.client, self.connected = self.client, None, False
            self.seq += 1
        if client is not None:
            try:
                client.close()
            except Exception:
                pass
        return ok(connected=False)

    def status(self):
        return {'connected': bool(self.connected), 'seq': self.seq,
                'host': self.peer['host'], 'port': self.peer['port'],
                'timeout': self.peer['timeout']}

    def _client_for(self, seq=None):
        """后台任务传它派发时的 seq：代次对不上说明连接已换，拒绝执行。"""
        if not self.connected or self.client is None:
            return None, fail('Modbus 未连接')
        if seq is not None and seq != self.seq:
            return None, fail('连接已变更，本轮读取作废（旧任务不写新设备）')
        return self.client, None

    def read(self, func, addr, count=1, seq=None):
        client, err = self._client_for(seq)
        if err:
            return err
        try:
            func, addr, count = int(func), int(addr), int(count)
        except (TypeError, ValueError):
            return fail('功能码 / 地址 / 数量必须是整数')
        if func not in READ_METHODS:
            return fail('不支持的读功能码：' + str(func))
        if not 0 <= addr <= 0xFFFF:
            return fail('地址超出范围（0~65535）')
        if not 1 <= count <= 125:
            return fail('数量需在 1~125 之间')

        method = getattr(client, READ_METHODS[func], None)
        if method is None:
            return fail('设备客户端不支持 ' + READ_METHODS[func])
        try:
            resp = method(addr, count=count) if MB_COUNT_KW else method(addr, count)
            if resp is None:
                return fail('设备无响应')
            if getattr(resp, 'isError', lambda: False)():
                return fail('设备拒绝请求：' + str(resp))
            # 按功能码取对应字段，不能用 `bits or registers`：
            # bits 是 [True, False] 时也是 truthy，读保持寄存器会拿到线圈值
            field = 'bits' if func in (1, 2) else 'registers'
            raw = list(getattr(resp, field, None) or [])
            return ok(func=func, addr=addr, values=raw[:count], raw=raw[:count])
        except Exception as exc:
            return fail('读取失败：' + (str(exc) or exc.__class__.__name__))

    def write(self, func, addr, value, seq=None):
        client, err = self._client_for(seq)
        if err:
            return err
        try:
            func, addr = int(func), int(addr)
        except (TypeError, ValueError):
            return fail('功能码 / 地址必须是整数')
        if func in READONLY_FUNCS:
            names = {2: '离散输入 (FC02)', 4: '输入寄存器 (FC04)'}
            return fail(names[func] + ' 是只读区，写入会落到同地址的另一个寄存器上')
        if func not in WRITE_METHODS:
            return fail('不支持的写功能码：' + str(func))
        if not 0 <= addr <= 0xFFFF:
            return fail('地址超出范围（0~65535）')
        try:
            val = int(str(value), 0) if isinstance(value, str) else int(value)
        except (TypeError, ValueError):
            return fail('值必须是整数（支持 0x 前缀）')

        method = getattr(client, WRITE_METHODS[func], None)
        if method is None:
            return fail('设备客户端不支持 ' + WRITE_METHODS[func])
        try:
            if func == 1:
                if val not in (0, 1):
                    return fail('线圈值只能是 0 或 1')
                resp = method(addr, bool(val))
            else:
                resp = method(addr, val & 0xFFFF)
            if resp is not None and getattr(resp, 'isError', lambda: False)():
                return fail('设备拒绝写入：' + str(resp))
            return ok(func=func, addr=addr, value=val & 0xFFFF if func == 3 else val)
        except Exception as exc:
            return fail('写入失败：' + (str(exc) or exc.__class__.__name__))

    def poll(self, points, seq=None):
        """批量读：points = [{'func':3,'addr':0,'count':1}, ...]。"""
        if not isinstance(points, list):
            return fail('points 必须是列表', results=[])
        results = []
        for p in points:
            if not isinstance(p, dict):
                results.append({'ok': False, 'error': '点位格式不对'})
                continue
            results.append(self.read(p.get('func'), p.get('addr'),
                                     p.get('count', 1), seq=seq))
        return ok(results=results, total=len(results))
