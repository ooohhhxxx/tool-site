# -*- coding: utf-8 -*-
"""串口业务内核：纯 pyserial，无 GUI 依赖。

对齐主程序踩过的坑：
1. 接收循环固定本轮 port 对象，重连后旧线程自动退出，不去读新端口。
2. 手动关闭先置 connected=False，循环结束才不误报「意外断开」。
3. 队列打满丢最旧，且统计的是**被挤掉那一包**的字节数（不是新包）。
4. 编码用 `codecs.getincrementaldecoder`，多字节 UTF-8 分两次到达也能正确解。
5. 端口名只记 COM3 这类设备名，不记整条描述（换驱动/换机器会连错设备）。
6. 统计只在有收发时更新，不做无条件的定时刷新。

所有方法返回 contract.ok / fail 形式的 dict。
"""
from __future__ import annotations

import base64
import codecs
import queue
import re
import threading
import time
from datetime import datetime

try:
    import serial
    from serial.tools import list_ports
except Exception:
    serial = None
    list_ports = None

from .contract import fail, ok  # noqa: E402

PARITY_MAP = {
    'None': 'N', 'N': 'N', 'Odd': 'O', 'O': 'O', 'Even': 'E', 'E': 'E',
    'Mark': 'M', 'M': 'M', 'Space': 'S', 'S': 'S',
}
STOPBITS_MAP = {'1': 1, '1.5': 1.5, '2': 2}


def normalise_port(name):
    """'COM3 - USB-SERIAL CH340' -> 'COM3'；Linux 设备路径原样返回。"""
    s = str(name or '').strip()
    return s.split(' - ')[0].strip() if ' - ' in s else s


class SerialService:
    def __init__(self, queue_max=2000):
        self.port = None
        self.connected = False
        self.encoding = 'utf-8'
        self.decoder = None
        self.queue = queue.Queue()
        self.queue_max = queue_max
        self.tx_bytes = 0
        self.rx_bytes = 0
        self.dropped_bytes = 0
        self._stop = threading.Event()
        self._rx_thread = None
        self._manual_close = False
        self.reset_decoder('utf-8')

    # ---------- 端口枚举 ----------
    @staticmethod
    def list_ports():
        if list_ports is None:
            return fail('未安装 pyserial 库', ports=[])
        try:
            rows = [{'device': p.device,
                     'description': str(getattr(p, 'description', '') or '')}
                    for p in list_ports.comports()]
            return ok(ports=rows)
        except Exception as exc:
            return fail('枚举串口失败：' + (str(exc) or exc.__class__.__name__), ports=[])

    # ---------- 连接 ----------
    def connect(self, port, baudrate=115200, bytesize=8, parity='None',
                stopbits='1', timeout=0.5, encoding='utf-8'):
        name = normalise_port(port)
        if not name:
            return fail('请选择串口端口')
        if self._rx_thread is not None and self._rx_thread.is_alive():
            return fail('上一次的接收线程尚未退出，请稍候再试')
        if serial is None:
            return fail('未安装 pyserial 库')
        try:
            baudrate, bytesize = int(baudrate), int(bytesize)
            timeout = float(timeout)
        except (TypeError, ValueError):
            return fail('波特率 / 数据位 / 超时必须是数字')
        if baudrate <= 0 or bytesize not in (5, 6, 7, 8) or timeout <= 0:
            return fail('串口参数超出范围')
        if str(parity) not in PARITY_MAP:
            return fail('不支持的校验位：' + str(parity))
        if str(stopbits) not in STOPBITS_MAP:
            return fail('不支持的停止位：' + str(stopbits))

        self._stop.clear()
        self._manual_close = False
        try:
            p = serial.Serial(
                port=name, baudrate=baudrate, bytesize=bytesize,
                parity=PARITY_MAP[str(parity)],
                stopbits=STOPBITS_MAP[str(stopbits)], timeout=timeout)
        except Exception as exc:
            return fail('打开串口失败：' + (str(exc) or exc.__class__.__name__))

        self.port = p
        self.connected = True
        self.tx_bytes = self.rx_bytes = self.dropped_bytes = 0
        self._drain_queue()
        self.reset_decoder(encoding)
        return ok(port=name, baudrate=baudrate, encoding=self.encoding)

    def disconnect(self):
        # 先断状态，接收循环结束时才不会误判成意外掉线
        self._manual_close = True
        self.connected = False
        self._stop.set()
        p, self.port = self.port, None
        if p is not None:
            try:
                p.close()
            except Exception:
                pass
        return ok(connected=False)

    def _drain_queue(self):
        try:
            while True:
                self.queue.get_nowait()
        except queue.Empty:
            pass

    # ---------- 编码 ----------
    def reset_decoder(self, encoding=None):
        enc = str(encoding or self.encoding or 'utf-8')
        try:
            self.decoder = codecs.getincrementaldecoder(enc)(errors='replace')
            self.encoding = enc
        except LookupError:
            self.decoder = codecs.getincrementaldecoder('utf-8')(errors='replace')
            self.encoding = 'utf-8'
        return self.encoding

    def decode(self, data):
        if self.decoder is None:
            self.reset_decoder()
        try:
            return self.decoder.decode(bytes(data or b''))
        except Exception:
            return bytes(data or b'').decode(self.encoding, errors='replace')

    # ---------- 发送 ----------
    def send(self, payload, hex_mode=False, newline=False):
        if not self.connected or self.port is None:
            return fail('串口未打开')
        if isinstance(payload, (bytes, bytearray)):
            data = bytes(payload)
            if not data:
                return fail('发送内容为空')
        elif hex_mode:
            text = str(payload or '')
            cleaned = re.sub(r'[^0-9a-fA-F\s]', ' ', text).split()
            if not cleaned:
                return fail('HEX 格式不正确，示例：01 03 00 00 00 01')
            if any(len(x) > 2 for x in cleaned):
                return fail('HEX 格式不正确：每段应为 1~2 位十六进制')
            try:
                data = bytes(int(x, 16) for x in cleaned)
            except ValueError:
                return fail('HEX 格式不正确：存在非单字节的段')
        else:
            text = str(payload or '')
            if not text:
                return fail('发送内容为空')
            try:
                data = text.encode(self.encoding, errors='replace')
            except LookupError:
                data = text.encode('utf-8', errors='replace')
        if newline:
            data += b'\r\n'
        try:
            self.port.write(data)
        except Exception as exc:
            return fail('发送失败：' + (str(exc) or exc.__class__.__name__))
        self.tx_bytes += len(data)
        return ok(bytes_sent=len(data), hex_mode=bool(hex_mode))

    # ---------- 接收 ----------
    def _enqueue(self, data):
        if self.queue.qsize() >= self.queue_max:
            try:
                evicted = self.queue.get_nowait()
                self.dropped_bytes += len(evicted[0])
            except queue.Empty:
                pass
        self.queue.put((bytes(data), datetime.now()))
        self.rx_bytes += len(data)

    def pump_once(self, port=None):
        """同步读一包（receive_loop 内部循环调用；也方便测试）。"""
        p = port or self.port
        if p is None:
            return None
        try:
            waiting = p.in_waiting
        except Exception:
            return None
        if not waiting:
            return None
        data = p.read(waiting)
        if data:
            self._enqueue(data)
            return data
        return None

    def receive_loop(self, on_data=None, on_error=None, on_lost=None):
        """固定本轮 port 对象；只有「仍显示已连接」才算意外断开。"""
        port = self.port
        while (self.connected and self.port is port and port is not None
               and not self._stop.is_set()):
            try:
                if not getattr(port, 'is_open', True):
                    break
                data = self.pump_once(port)
                if data is not None and on_data:
                    try:
                        on_data(data, self.decode(data))
                    except Exception:
                        pass
                else:
                    self._stop.wait(0.01)
            except Exception as exc:
                if on_error:
                    try:
                        on_error(str(exc) or exc.__class__.__name__)
                    except Exception:
                        pass
                break
        if self.connected and self.port is port and not self._manual_close and on_lost:
            try:
                on_lost()
            except Exception:
                pass

    def start_receive(self, on_data=None, on_error=None, on_lost=None):
        if self._rx_thread is not None and self._rx_thread.is_alive():
            return fail('接收线程已在运行')
        self._rx_thread = threading.Thread(
            target=self.receive_loop, args=(on_data, on_error, on_lost),
            daemon=True, name='serial-rx')
        self._rx_thread.start()
        return ok(started=True)

    def take(self, max_items=100):
        """取走队列里已收到的数据，供前端轮询。

        bytes 用 base64 跨 UI 边界；解码留给前端的 TextDecoder(stream)，
        这样不破坏内核增量解码器的顺序状态，也能支持 GBK 等编码。
        """
        try:
            limit = max(1, min(int(max_items or 100), 1000))
        except (TypeError, ValueError):
            limit = 100
        items = []
        for _ in range(limit):
            try:
                data, ts = self.queue.get_nowait()
            except queue.Empty:
                break
            items.append({
                'data': base64.b64encode(data).decode('ascii'),
                'ts': ts.strftime('%H:%M:%S.%f')[:-3],
                'nbytes': len(data),
            })
        return ok(items=items, **self.stats())

    def read_bytes(self, timeout=0.5):
        """给插件用：阻塞最多 timeout 秒，把这段时间收到的数据一次性返回。"""
        try:
            deadline = time.time() + max(0.05, min(float(timeout), 10.0))
        except (TypeError, ValueError):
            deadline = time.time() + 0.5
        buf = bytearray()
        while True:
            try:
                data, _ts = self.queue.get_nowait()
                buf += data
            except queue.Empty:
                if time.time() >= deadline:
                    break
                time.sleep(0.02)
            else:
                if time.time() >= deadline:
                    break
        return ok(data=bytes(buf), nbytes=len(buf))

    def stats(self):
        return {'connected': bool(self.connected), 'tx': self.tx_bytes,
                'rx': self.rx_bytes, 'dropped': self.dropped_bytes,
                'queued': self.queue.qsize(), 'encoding': self.encoding}
