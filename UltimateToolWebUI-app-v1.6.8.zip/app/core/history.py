# -*- coding: utf-8 -*-
"""连接记录内核：从主程序 `load_ssh_history` / `_write_ssh_history` 抽出的无 GUI 版本。

行为对齐：
- 根节点必须是 list；合法条目需含 host / user / port，port 统一成字符串
- 读不懂的条目（junk）不进列表，但写回时原样带回，绝不悄悄抹掉
- 上限 50 条，超出从头部丢（最新在末尾），并在结果里说明
- 对外只给脱敏字段；password / enc / key 等留在内核里，不跨边界

不依赖 tkinter / 主程序，可脱离窗口单测。
"""
from __future__ import annotations

import json
import os
import pathlib

from .config import atomic_write_json
from .contract import fail, ok, public_host

MAX_HISTORY = 50
DEFAULT_HISTORY = os.path.join(os.path.expanduser('~'), '.ssh_gui_history.json')


def _valid(item):
    return isinstance(item, dict) and all(k in item for k in ('host', 'user', 'port'))


class HistoryStore:
    def __init__(self, path=None):
        self.path = str(path or os.environ.get('ULTIMATE_TOOL_HISTORY') or DEFAULT_HISTORY)
        self._raw = []      # 合法记录，保留全部字段（含密文密码）
        self._junk = []     # 读不懂的原始条目，写回时带回
        self.dropped = 0
        self.note = ''

    def load(self):
        """返回 Result：{'ok', 'hosts'(脱敏), 'total', 'junk', 'dropped', 'note', 'source'}。"""
        self._raw, self._junk, self.dropped, self.note = [], [], 0, ''
        if not os.path.exists(self.path):
            return ok(hosts=[], total=0, junk=0, dropped=0, note='',
                      source=pathlib.Path(self.path).name)
        try:
            with open(self.path, 'r', encoding='utf-8-sig') as f:
                raw = json.load(f)
            if not isinstance(raw, list):
                raise ValueError('连接记录文件的根节点不是列表')
        except Exception as exc:
            return fail(str(exc) or exc.__class__.__name__, hosts=[], total=0,
                        junk=0, dropped=0, source=pathlib.Path(self.path).name)

        for item in raw:
            if _valid(item):
                item = dict(item)
                item['port'] = str(item['port'])
                self._raw.append(item)
            else:
                self._junk.append(item)

        if len(self._raw) > MAX_HISTORY:
            self.dropped = len(self._raw) - MAX_HISTORY
            self._raw = self._raw[-MAX_HISTORY:]
        if self._junk:
            self.note = f'有 {len(self._junk)} 条记录格式不对，已忽略（文件里仍保留）'
        elif self.dropped:
            self.note = f'连接记录较多，只显示最近 {MAX_HISTORY} 条'

        return ok(hosts=[public_host(x) for x in self._raw],
                  total=len(self._raw), junk=len(self._junk),
                  dropped=self.dropped, note=self.note,
                  source=pathlib.Path(self.path).name)

    def add(self, host, port, user, **extra):
        """追加一条记录并落盘。extra 可含 password/enc/key，只写文件不外泄。"""
        item = {'host': str(host), 'port': str(port), 'user': str(user)}
        item.update(extra)
        self._raw.append(item)
        if len(self._raw) > MAX_HISTORY:
            self.dropped += len(self._raw) - MAX_HISTORY
            self._raw = self._raw[-MAX_HISTORY:]
        return self.save()

    def remove(self, host, port=None, user=None):
        """删除匹配的记录（host 必填；给了 port/user 就一起匹配）。返回删除条数。"""
        host = str(host or '').strip()
        if not host:
            return fail('主机不能为空')
        kept = []
        for item in self._raw:
            same = str(item.get('host', '')) == host
            if same and port not in (None, ''):
                same = str(item.get('port', '')) == str(port)
            if same and user not in (None, ''):
                same = str(item.get('user', '')) == str(user)
            if not same:
                kept.append(item)
        removed = len(self._raw) - len(kept)
        if not removed:
            return fail('没有匹配的记录')
        self._raw = kept
        saved = self.save()
        if not saved['ok']:
            return saved
        return ok(removed=removed, total=len(self._raw))

    def save(self):
        try:
            pathlib.Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            return fail(exc)
        if not atomic_write_json(self.path, self._raw + self._junk, indent=4):
            return fail('写入连接记录失败（磁盘空间、权限或文件被占用）')
        return ok(path=self.path, total=len(self._raw))
