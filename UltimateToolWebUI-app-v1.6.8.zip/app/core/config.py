# -*- coding: utf-8 -*-
"""配置内核：从主程序 `_load_conf` / `_atomic_write_json` 抽出的无 GUI 版本。

行为与主程序保持一致（这是刻意的，换新 UI 不能改变用户已存的数据）：
- 读用 utf-8-sig（记事本改过会带 BOM，不能被当成损坏）
- 坏文件先备份成 `.bak-时间戳` 再按空配置启动，绝不静默丢数据
- 写用 `.tmp → fsync → os.replace`，断电不会留半截文件
- 路径可用 ULTIMATE_TOOL_CONF 覆盖（测试隔离）

不依赖 tkinter / 主程序，可脱离窗口单测。
"""
from __future__ import annotations

import json
import os
import pathlib
from datetime import datetime

from .contract import fail, ok

DEFAULT_CONF = os.path.join(os.path.expanduser('~'), '.ssh_gui_conf.json')


def atomic_write_json(path, data, indent=2):
    """原子写 JSON；成功 True，失败 False 且不留 .tmp 垃圾。"""
    tmp = str(path) + '.tmp'
    try:
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=indent)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
        return True
    except Exception:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except OSError:
            pass
        return False


class ConfigStore:
    def __init__(self, path=None):
        self.path = str(path or os.environ.get('ULTIMATE_TOOL_CONF') or DEFAULT_CONF)
        self.data = {}
        self.load_error = None
        self.backup_path = None

    def load(self):
        """返回 Result：{'ok', 'data', 'error'?, 'backup'?, 'fresh'}。"""
        self.data, self.load_error, self.backup_path = {}, None, None
        if not os.path.exists(self.path):
            return ok(data={}, fresh=True)
        try:
            with open(self.path, 'r', encoding='utf-8-sig') as f:
                raw = json.load(f)
            if not isinstance(raw, dict):
                raise ValueError('配置文件的根节点不是对象')
            self.data = raw
            return ok(data=raw, fresh=False)
        except Exception as exc:
            reason = str(exc) or exc.__class__.__name__
            stamp = datetime.now().strftime('%Y%m%d-%H%M%S')
            try:
                backup = self.path + '.bak-' + stamp
                os.replace(self.path, backup)
                self.backup_path = backup
            except Exception:
                pass
            self.load_error = reason
            return fail(reason, data={}, backup=self.backup_path, fresh=False)

    def get(self, section, key, default=None):
        sec = self.data.get(section) if isinstance(self.data, dict) else None
        if not isinstance(sec, dict):
            return default
        return sec.get(key, default)

    def set(self, section, key, value):
        if not isinstance(self.data, dict):
            self.data = {}
        self.data.setdefault(section, {})[key] = value
        return self

    def save(self, data=None, indent=2):
        if data is not None:
            self.data = data
        parent = pathlib.Path(self.path).parent
        try:
            parent.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            return fail(exc)
        if not atomic_write_json(self.path, self.data, indent=indent):
            return fail('写入配置失败（磁盘空间、权限或文件被占用）')
        return ok(path=self.path)
