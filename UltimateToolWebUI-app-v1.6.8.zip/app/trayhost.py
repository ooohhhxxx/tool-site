# -*- coding: utf-8 -*-
"""把 tray.py 的 TrayController 接到 pywebview 窗口上。

tray.py 是给 Tk 版写的，只依赖宿主的三样东西：`_ui_call` / `show_from_tray` / `_shutdown`。
这里补上这三个，并保留 1.6.6 修过的那条：托盘线程启动后若崩掉，窗口已经藏起来
就再也找不回来 —— 所以隐藏后要延迟复查一次，图标不在就把窗口复原。

pywebview 的 hide/show 内部已经 Invoke 到 WinForms UI 线程，从这里（pystray 线程）调用是安全的。
"""
from __future__ import annotations

import threading


class TrayHost:
    def __init__(self, window, icon_path, on_quit=None):
        self.window = window
        self.icon_path = str(icon_path)
        self._on_quit = on_quit
        self.tray = None
        self.hidden = False
        self._lock = threading.Lock()

    # ---------- 生命周期 ----------
    def available(self):
        try:
            from tray import TrayController
            return bool(TrayController.available())
        except Exception:
            return False

    def start(self):
        if self.tray is not None:
            return True
        try:
            from tray import TrayController
        except Exception:
            return False
        if not TrayController.available():
            return False
        with self._lock:
            tray = TrayController(self, self.icon_path)
            if not tray.show():
                return False
            self.tray = tray
            return True

    def stop(self):
        with self._lock:
            tray, self.tray = self.tray, None
        if tray is not None:
            try:
                tray.hide()
            except Exception:
                pass

    # ---------- tray.py 需要的宿主接口 ----------
    def _ui_call(self, fn, *args):
        try:
            fn(*args)
        except Exception:
            pass

    def show_from_tray(self):
        try:
            self.window.show()
            self.window.restore()
        except Exception:
            pass
        self.hidden = False
        self.stop()

    def _shutdown(self):
        self.stop()
        if self._on_quit:
            try:
                self._on_quit()
            except Exception:
                pass

    # ---------- 隐藏 / 复查 ----------
    def hide_to_tray(self):
        if not self.start():
            return False
        try:
            self.window.hide()
        except Exception:
            self.stop()
            return False
        self.hidden = True
        threading.Timer(0.6, self._verify).start()
        return True

    def _verify(self):
        tray = self.tray
        if tray is not None and getattr(tray, 'alive', True):
            return
        # 图标没了：窗口还藏着就等于程序消失了，必须复原
        try:
            self.window.show()
            self.window.restore()
        except Exception:
            pass
        self.hidden = False
        self.stop()
