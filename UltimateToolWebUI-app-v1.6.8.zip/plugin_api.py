# -*- coding: utf-8 -*-
"""插件接口定义 —— 宿主（ssh_modbus_tool.py）与插件之间唯一的契约。

写一个插件只要三步：

1. 在 `plugins/` 目录下新建 `xxx.py`（文件名以 `_` 开头会被忽略）；
2. `import plugin_api`，定义 `class Plugin(plugin_api.PluginBase)`；
3. 文件末尾写 `PLUGIN = Plugin`（写类或实例都行）。

启动工具后，「插件」标签页会自动列出它。

--------------------------------------------------------------------------
宿主 API（host）速查
--------------------------------------------------------------------------
日志与线程
    host.log(msg, level="info")      level: info / success / warn / error
    host.info/ success/ warn/ error(msg)         日志简写
    host.sleep(seconds) -> bool      可中断等待；返回 False 表示插件已被停止，循环里应退出
    host.stop_requested -> bool      是否已请求停止
    host.ensure("ssh"|"modbus"|"serial")         未连接时抛 PluginError
    host.run_async(func, *args)      后台线程跑 func（异常自动记日志）；同一插件同时只跑一个
                                     任务，抢不到执行位时返回 None —— 面板回调要据此把自己
                                     的「进行中」状态退回去。每次派发都会清掉停止标志。
    host.is_busy -> bool             本插件当前有没有任务在跑（面板按钮用它防连点）
    host.data_dir                    本插件专属的可写目录（自动创建）

SSH
    host.ssh.connected -> bool
    host.ssh.exec(cmd, timeout=15) -> ExecResult(exit_status, stdout, stderr)
        命令里的非 ASCII 字符怎么发、返回的字节怎么解，都跟界面上 SSH「编码」
        下拉框一致（默认 UTF-8；纯 ASCII 命令两种编码字节相同）
    host.ssh.listdir(path) -> [{"name","size","mtime","is_dir","is_link"}, ...]
    host.ssh.stat(path)    ->  同上单个 dict
    host.ssh.upload(local, remote, callback=None)     callback(done, total)
    host.ssh.download(remote, local, callback=None)
    host.ssh.read_text(path, encoding="utf-8") -> str
    host.ssh.write_text(path, text, encoding="utf-8")
    host.ssh.cwd -> str               当前远程目录（文件页里选中的目录）

Modbus TCP
    host.modbus.connected -> bool
    host.modbus.read(kind, addr, count=1) -> [int|bool, ...]
        kind: "coil"(01) / "discrete"(02) / "holding"(03) / "input"(04)
    host.modbus.write(kind, addr, value) -> bool
        kind = "coil"     value = True/False
        kind = "holding"  value = 整数
        kind = "coils"    value = [True, False, ...]
        kind = "holdings" value = [1, 2, 3, ...]

串口
    host.serial.connected -> bool
    host.serial.ports() -> ["COM3", ...]
    host.serial.send(data)             bytes 原样发；str 按串口界面「编码」下拉框编
    host.serial.send_line(text)        发送 text + "\\n"（同上，按界面选的编码编）
    host.serial.read(timeout=0.5) -> bytes   收满 timeout 或收到数据后返回（独立缓冲，不影响接收区显示）
    host.serial.flush()                清空插件侧的接收缓冲

其它
    host.app          宿主 GUI 实例（高级用法，可直接调用其方法；注意线程安全）
    host.plugin       本插件实例
    host.plugin_name / host.plugin_dir / host.api_version
"""

from __future__ import annotations

import dataclasses
from typing import Any, Callable, List, Optional, Sequence, Tuple

# 宿主提供的 API 版本号：不兼容变更时递增，插件可据此做兼容判断
PLUGIN_API_VERSION = 1


class PluginError(Exception):
    """插件里主动抛出的、需要以人话展示给用户的错误。"""


@dataclasses.dataclass
class Command:
    """插件暴露给宿主界面的一个可执行动作。

    func 会被宿主在后台线程中调用，签名为 func(host)。
    """

    label: str
    func: Callable[[Any], Any]
    description: str = ""


@dataclasses.dataclass
class ExecResult:
    """SSH 命令执行结果。"""

    exit_status: int
    stdout: str = ""
    stderr: str = ""

    @property
    def ok(self) -> bool:
        return self.exit_status == 0

    @property
    def output(self) -> str:
        """合并的 stdout/stderr，方便直接打印。"""
        parts = [p for p in (self.stdout, self.stderr) if p]
        return "\n".join(parts)


class PluginBase:
    """所有插件的基类。只有 NAME 和 commands() 是必须的。"""

    #: 显示在插件列表里的名字
    NAME = "未命名插件"
    VERSION = "0.1.0"
    DESCRIPTION = ""
    AUTHOR = ""
    #: 声明依赖的连接类型，仅用于界面提示与 host.ensure 校验建议
    #: 例如 ("ssh",) / ("modbus", "serial")
    REQUIRES: Sequence[str] = ()
    #: 是否默认启用：用户在插件页里手动开关过的插件以他的选择为准，
    #: 只有从没动过的插件才看这个值（决定于加载前的静态扫描，不会先导入再藏起来）
    ENABLED_BY_DEFAULT = True

    def on_load(self, host) -> None:
        """插件被加载时调用（此时连接可能还没建立）。"""

    def on_unload(self) -> None:
        """插件被卸载/禁用/退出程序时调用，用来释放资源、停止线程。"""

    def commands(self) -> List[Command]:
        """返回本插件暴露的动作列表，宿主会列在插件页里逐个触发。"""
        return []

    def create_panel(self, parent, host) -> Optional[Any]:
        """可选：在插件页右侧挂一块自定义界面。

        parent 是一个已 pack 好的 tk.Frame，往里放控件即可；
        返回值会被忽略，返回 None 表示本插件没有界面。
        注意：本方法在主线程调用，可以安全地操作 Tk；
        但按钮回调里不要做耗时操作，请用 host.run_async 或 Command。
        """
        return None
